<script>
	export default {}
</script>

/* App.vue */
<style lang="scss">
	@import "uview-ui/index.scss";
</style>
