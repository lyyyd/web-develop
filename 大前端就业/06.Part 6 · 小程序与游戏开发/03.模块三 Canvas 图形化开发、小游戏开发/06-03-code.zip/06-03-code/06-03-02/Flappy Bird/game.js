

import Main from './js/main.js'

new Main()
