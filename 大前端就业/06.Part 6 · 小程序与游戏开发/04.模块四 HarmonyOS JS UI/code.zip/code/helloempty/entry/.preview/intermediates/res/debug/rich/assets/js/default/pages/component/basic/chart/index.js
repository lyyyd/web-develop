/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\component\\basic\\chart\\index.hml?entry");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./lib/json.js!./lib/style.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\component\\basic\\chart\\index.css":
/*!**************************************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/style.js!D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/pages/component/basic/chart/index.css ***!
  \**************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  ".container": {
    "flexDirection": "column",
    "justifyContent": "center",
    "alignItems": "center"
  },
  ".chart-region": {
    "height": "400px",
    "width": "700px"
  },
  ".chart-background": {
    "objectFit": "fill"
  },
  ".chart-data": {
    "width": "700px",
    "height": "600px"
  },
  ".data-region": {
    "height": "400px",
    "width": "700px"
  },
  ".data-background": {
    "objectFit": "fill"
  },
  ".data-bar": {
    "width": "700px",
    "height": "400px"
  },
  ".gauge-region": {
    "height": "400px",
    "width": "400px"
  },
  ".data-gauge": {
    "colors": "#83f115,#fd3636,#3bf8ff",
    "weights": "4,2,2"
  }
}

/***/ }),

/***/ "./lib/json.js!./lib/template.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\component\\basic\\chart\\index.hml":
/*!*****************************************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/template.js!D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/pages/component/basic/chart/index.hml ***!
  \*****************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  "attr": {
    "debugLine": "pages/component/basic/chart/index:1",
    "className": "container"
  },
  "type": "div",
  "classList": [
    "container"
  ],
  "children": [
    {
      "attr": {
        "debugLine": "pages/component/basic/chart/index:2",
        "value": "折线图"
      },
      "type": "text"
    },
    {
      "attr": {
        "debugLine": "pages/component/basic/chart/index:3",
        "className": "chart-region"
      },
      "type": "stack",
      "classList": [
        "chart-region"
      ],
      "children": [
        {
          "attr": {
            "debugLine": "pages/component/basic/chart/index:4",
            "className": "chart-background",
            "src": "common/images/Wallpaper.png"
          },
          "type": "image",
          "classList": [
            "chart-background"
          ]
        },
        {
          "attr": {
            "debugLine": "pages/component/basic/chart/index:5",
            "className": "chart-data",
            "type": "line",
            "ref": "linechart",
            "options": function () {return this.lineOps},
            "datasets": function () {return this.lineData}
          },
          "type": "chart",
          "classList": [
            "chart-data"
          ]
        }
      ]
    },
    {
      "attr": {
        "debugLine": "pages/component/basic/chart/index:11",
        "value": "Add data",
        "type": "capsule"
      },
      "type": "button",
      "events": {
        "click": "addData"
      }
    },
    {
      "attr": {
        "debugLine": "pages/component/basic/chart/index:15",
        "value": "柱状图"
      },
      "type": "text"
    },
    {
      "attr": {
        "debugLine": "pages/component/basic/chart/index:16",
        "className": "data-region"
      },
      "type": "stack",
      "classList": [
        "data-region"
      ],
      "children": [
        {
          "attr": {
            "debugLine": "pages/component/basic/chart/index:17",
            "className": "data-background",
            "src": "common/images/Wallpaper.png"
          },
          "type": "image",
          "classList": [
            "data-background"
          ]
        },
        {
          "attr": {
            "debugLine": "pages/component/basic/chart/index:18",
            "className": "data-bar",
            "type": "bar",
            "id": "bar-chart",
            "options": function () {return this.barOps},
            "datasets": function () {return this.barData}
          },
          "type": "chart",
          "classList": [
            "data-bar"
          ],
          "id": "bar-chart"
        }
      ]
    },
    {
      "attr": {
        "debugLine": "pages/component/basic/chart/index:25",
        "value": "量规图"
      },
      "type": "text"
    },
    {
      "attr": {
        "debugLine": "pages/component/basic/chart/index:26",
        "className": "gauge-region"
      },
      "type": "div",
      "classList": [
        "gauge-region"
      ],
      "children": [
        {
          "attr": {
            "debugLine": "pages/component/basic/chart/index:27",
            "className": "data-gauge",
            "type": "gauge",
            "percent": "50"
          },
          "type": "chart",
          "classList": [
            "data-gauge"
          ]
        }
      ]
    },
    {
      "attr": {
        "debugLine": "pages/component/basic/chart/index:32",
        "value": "progress"
      },
      "type": "text"
    },
    {
      "attr": {
        "debugLine": "pages/component/basic/chart/index:33",
        "className": "data-region"
      },
      "type": "stack",
      "classList": [
        "data-region"
      ],
      "children": [
        {
          "attr": {
            "debugLine": "pages/component/basic/chart/index:34",
            "className": "data-background",
            "src": "common/images/Wallpaper.png"
          },
          "type": "image",
          "classList": [
            "data-background"
          ]
        },
        {
          "attr": {
            "debugLine": "pages/component/basic/chart/index:35",
            "className": "data-bar",
            "type": "progress",
            "id": "progress-chart",
            "segments": function () {return this.segmentsData}
          },
          "type": "chart",
          "classList": [
            "data-bar"
          ],
          "id": "progress-chart"
        }
      ]
    }
  ]
}

/***/ }),

/***/ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\component\\basic\\chart\\index.js":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./lib/script.js!./node_modules/babel-loader/lib?presets[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/pages/component/basic/chart/index.js ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function(module, exports, $app_require$){"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var _default = {
  data: {
    lineData: [{
      strokeColor: '#0081ff',
      fillColor: '#cce5ff',
      data: [763, 550, 551, 554, 731, 654, 525, 696, 595, 628, 791, 505, 613, 575, 475, 553, 491, 680, 657, 716],
      gradient: true
    }],
    lineOps: {
      xAxis: {
        min: 0,
        max: 20,
        display: false
      },
      yAxis: {
        min: 0,
        max: 1000,
        display: false
      },
      series: {
        lineStyle: {
          width: "5px",
          smooth: true
        },
        headPoint: {
          shape: "circle",
          size: 20,
          strokeWidth: 5,
          fillColor: '#ffffff',
          strokeColor: '#007aff',
          display: true
        },
        loop: {
          margin: 2,
          gradient: true
        }
      }
    },
    barData: [{
      fillColor: '#f07826',
      data: [763, 550, 551, 554, 731, 654, 525, 696, 595, 628]
    }, {
      fillColor: '#cce5ff',
      data: [535, 776, 615, 444, 694, 785, 677, 609, 562, 410]
    }, {
      fillColor: '#ff88bb',
      data: [673, 500, 574, 483, 702, 583, 437, 506, 693, 657]
    }],
    barOps: {
      xAxis: {
        min: 0,
        max: 20,
        display: false,
        axisTick: 10
      },
      yAxis: {
        min: 0,
        max: 1000,
        display: false
      }
    },
    segmentsData: {
      startColor: '#9973d1',
      endColor: '#555555',
      value: 80,
      name: '已完成'
    }
  },
  addData: function addData() {
    this.$refs.linechart.append({
      serial: 0,
      data: [Math.floor(Math.random() * 400) + 400]
    });
  }
};
exports["default"] = _default;
var moduleOwn = exports.default || module.exports;
var accessors = ['public', 'protected', 'private'];
if (moduleOwn.data && accessors.some(function (acc) {
    return moduleOwn[acc];
  })) {
  throw new Error('For VM objects, attribute data must not coexist with public, protected, or private. Please replace data with public.');
} else if (!moduleOwn.data) {
  moduleOwn.data = {};
  moduleOwn._descriptor = {};
  accessors.forEach(function(acc) {
    var accType = typeof moduleOwn[acc];
    if (accType === 'object') {
      moduleOwn.data = Object.assign(moduleOwn.data, moduleOwn[acc]);
      for (var name in moduleOwn[acc]) {
        moduleOwn._descriptor[name] = {access : acc};
      }
    } else if (accType === 'function') {
      console.warn('For VM objects, attribute ' + acc + ' value must not be a function. Change the value to an object.');
    }
  });
}}
/* generated by ace-loader */


/***/ }),

/***/ "D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\component\\basic\\chart\\index.hml?entry":
/*!***************************************************************************************************************!*\
  !*** D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/pages/component/basic/chart/index.hml?entry ***!
  \***************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $app_template$ = __webpack_require__(/*! !./lib/json.js!./lib/template.js!./index.hml */ "./lib/json.js!./lib/template.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\component\\basic\\chart\\index.hml")
var $app_style$ = __webpack_require__(/*! !./lib/json.js!./lib/style.js!./index.css */ "./lib/json.js!./lib/style.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\component\\basic\\chart\\index.css")
var $app_script$ = __webpack_require__(/*! !./lib/script.js!./node_modules/babel-loader?presets[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!./index.js */ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\component\\basic\\chart\\index.js")

$app_define$('@app-component/index', [], function($app_require$, $app_exports$, $app_module$) {

$app_script$($app_module$, $app_exports$, $app_require$)
if ($app_exports$.__esModule && $app_exports$.default) {
$app_module$.exports = $app_exports$.default
}

$app_module$.exports.template = $app_template$

$app_module$.exports.style = $app_style$

})
$app_bootstrap$('@app-component/index',undefined,undefined)

/***/ })

/******/ });