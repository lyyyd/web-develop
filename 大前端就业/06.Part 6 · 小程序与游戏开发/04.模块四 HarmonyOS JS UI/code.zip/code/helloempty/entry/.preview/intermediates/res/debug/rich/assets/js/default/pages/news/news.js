/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\news\\news.hml?entry");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./lib/json.js!./lib/style.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\components\\bottomNav\\index.css":
/*!**************************************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/style.js!D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/common/components/bottomNav/index.css ***!
  \**************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {}

/***/ }),

/***/ "./lib/json.js!./lib/style.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\news\\news.css":
/*!********************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/style.js!D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/pages/news/news.css ***!
  \********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  ".container": {
    "display": "flex",
    "flexDirection": "column",
    "justifyContent": "flex-start",
    "alignItems": "center",
    "left": "0px",
    "top": "0px"
  },
  ".list": {
    "marginRight": "14px",
    "width": "100%"
  },
  ".list-item": {
    "height": "94px",
    "width": "100%",
    "marginTop": "0px",
    "marginRight": "10px",
    "marginBottom": "0px",
    "marginLeft": "10px",
    "display": "flex",
    "flexDirection": "row",
    "alignItems": "center"
  },
  ".list-image": {
    "height": "66px",
    "width": "66px"
  },
  ".content": {
    "display": "flex",
    "flexDirection": "column",
    "justifyContent": "center",
    "flexGrow": 1
  },
  ".list-text": {
    "marginLeft": "16px",
    "fontSize": "15px"
  },
  ".list-title": {
    "lineHeight": "20px",
    "overflow": "hidden",
    "whiteSpace": "nowrap",
    "textOverflow": "ellipsis",
    "marginBottom": "5px"
  },
  ".list-meta": {
    "marginLeft": "16px",
    "fontSize": "14px",
    "textColor": "#333333",
    "marginBottom": "5px"
  },
  ".right-image": {
    "width": "30px",
    "height": "30px"
  },
  ".tab-text": {
    "fontSize": "20px"
  }
}

/***/ }),

/***/ "./lib/json.js!./lib/template.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\components\\bottomNav\\index.hml":
/*!*****************************************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/template.js!D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/common/components/bottomNav/index.hml ***!
  \*****************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  "attr": {
    "debugLine": "common/components/bottomNav/index:1"
  },
  "type": "toolbar",
  "style": {
    "position": "fixed",
    "bottom": "0px"
  },
  "children": [
    {
      "attr": {
        "debugLine": "common/components/bottomNav/index:2",
        "tid": "id",
        "icon": function () {return this.$item.icon},
        "value": function () {return this.$item.name}
      },
      "type": "toolbar-item",
      "repeat": function () {return this.menu},
      "events": {
        "click": function (evt) {this.changeNav(this.$idx,evt)}
      }
    }
  ]
}

/***/ }),

/***/ "./lib/json.js!./lib/template.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\news\\news.hml":
/*!***********************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/template.js!D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/pages/news/news.hml ***!
  \***********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  "attr": {
    "debugLine": "pages/news/news:4",
    "className": "container"
  },
  "type": "div",
  "classList": [
    "container"
  ],
  "children": [
    {
      "attr": {
        "debugLine": "pages/news/news:5",
        "className": "tabs",
        "index": "0",
        "vertical": "false"
      },
      "type": "tabs",
      "classList": [
        "tabs"
      ],
      "events": {
        "change": "change"
      },
      "children": [
        {
          "attr": {
            "debugLine": "pages/news/news:6",
            "className": "tab-bar",
            "mode": "scrollable"
          },
          "type": "tab-bar",
          "classList": [
            "tab-bar"
          ],
          "children": [
            {
              "attr": {
                "debugLine": "pages/news/news:7",
                "className": "tab-text",
                "value": function () {return this.$item.title}
              },
              "type": "text",
              "classList": [
                "tab-text"
              ],
              "repeat": function () {return this.news}
            }
          ]
        },
        {
          "attr": {
            "debugLine": "pages/news/news:9",
            "className": "tabcontent",
            "scrollable": "true"
          },
          "type": "tab-content",
          "classList": [
            "tabcontent"
          ],
          "children": [
            {
              "attr": {
                "debugLine": "pages/news/news:10",
                "className": "item-content"
              },
              "type": "div",
              "classList": [
                "item-content"
              ],
              "repeat": function () {return this.news},
              "children": [
                {
                  "attr": {
                    "debugLine": "pages/news/news:11",
                    "className": "list"
                  },
                  "type": "list",
                  "classList": [
                    "list"
                  ],
                  "shown": function () {return this.$item.list.length},
                  "children": [
                    {
                      "attr": {
                        "debugLine": "pages/news/news:12",
                        "className": "list-item"
                      },
                      "type": "list-item",
                      "repeat": function () {return this.$item.list},
                      "classList": [
                        "list-item"
                      ],
                      "events": {
                        "click": function (evt) {this.clickItem(this.$item.uniquekey,evt)}
                      },
                      "children": [
                        {
                          "attr": {
                            "debugLine": "pages/news/news:15",
                            "src": function () {return this.$item.thumbnail_pic_s},
                            "className": "list-image"
                          },
                          "type": "image",
                          "classList": [
                            "list-image"
                          ]
                        },
                        {
                          "attr": {
                            "debugLine": "pages/news/news:16",
                            "className": "content"
                          },
                          "type": "div",
                          "classList": [
                            "content"
                          ],
                          "children": [
                            {
                              "attr": {
                                "debugLine": "pages/news/news:17",
                                "className": "list-text list-title",
                                "value": function () {return this.$item.title}
                              },
                              "type": "text",
                              "classList": [
                                "list-text",
                                "list-title"
                              ]
                            },
                            {
                              "attr": {
                                "debugLine": "pages/news/news:20",
                                "className": "list-meta",
                                "focusable": "true",
                                "value": function () {return this.$item.author_name}
                              },
                              "type": "text",
                              "classList": [
                                "list-meta"
                              ]
                            },
                            {
                              "attr": {
                                "debugLine": "pages/news/news:23",
                                "className": "list-text",
                                "focusable": "true",
                                "value": function () {return this.$item.date}
                              },
                              "type": "text",
                              "classList": [
                                "list-text"
                              ]
                            }
                          ]
                        },
                        {
                          "attr": {
                            "debugLine": "pages/news/news:27",
                            "className": "right-image",
                            "src": "/common/icons/right_active.png"
                          },
                          "type": "image",
                          "classList": [
                            "right-image"
                          ]
                        }
                      ]
                    }
                  ]
                }
              ]
            }
          ]
        }
      ]
    },
    {
      "attr": {
        "debugLine": "pages/news/news:35",
        "curIndex": "1"
      },
      "type": "bottomnav"
    }
  ]
}

/***/ }),

/***/ "./lib/loader.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\components\\bottomNav\\index.hml?name=bottomnav":
/*!****************************************************************************************************************************************!*\
  !*** ./lib/loader.js!D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/common/components/bottomNav/index.hml?name=bottomnav ***!
  \****************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $app_template$ = __webpack_require__(/*! !./lib/json.js!./lib/template.js!./index.hml */ "./lib/json.js!./lib/template.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\components\\bottomNav\\index.hml")
var $app_style$ = __webpack_require__(/*! !./lib/json.js!./lib/style.js!./index.css */ "./lib/json.js!./lib/style.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\components\\bottomNav\\index.css")
var $app_script$ = __webpack_require__(/*! !./lib/script.js!./node_modules/babel-loader?presets[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!./index.js */ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\components\\bottomNav\\index.js")

$app_define$('@app-component/bottomnav', [], function($app_require$, $app_exports$, $app_module$) {

$app_script$($app_module$, $app_exports$, $app_require$)
if ($app_exports$.__esModule && $app_exports$.default) {
$app_module$.exports = $app_exports$.default
}

$app_module$.exports.template = $app_template$

$app_module$.exports.style = $app_style$

})


/***/ }),

/***/ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\components\\bottomNav\\index.js":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./lib/script.js!./node_modules/babel-loader/lib?presets[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/common/components/bottomNav/index.js ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = function(module, exports, $app_require$){"use strict";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _system = _interopRequireDefault($app_require$("@app-module/system.router"));

var _default = {
  props: ['curIndex'],
  data: {
    menu: [{
      icon: 'common/icons/home.png',
      active_icon: 'common/icons/home_active.png',
      name: '首页',
      path: 'pages/index/index',
      active: true
    }, {
      icon: 'common/icons/comment.png',
      active_icon: 'common/icons/comment_active.png',
      name: '新闻',
      path: 'pages/news/news',
      active: false
    }, {
      icon: 'common/icons/cart.png',
      active_icon: 'common/icons/cart_active.png',
      name: '组件',
      path: 'pages/component/component',
      active: false
    }, {
      icon: 'common/icons/user.png',
      active_icon: 'common/icons/user_active.png',
      name: '我',
      path: 'pages/profile/index',
      active: false
    }]
  },
  onInit: function onInit() {
    this.menu[this.curIndex].icon = this.menu[this.curIndex].active_icon;
  },
  changeNav: function changeNav(id) {
    console.log('current id: ' + id);

    _system["default"].replace({
      uri: this.menu[id].path
    });
  }
};
exports["default"] = _default;
var moduleOwn = exports.default || module.exports;
var accessors = ['public', 'protected', 'private'];
if (moduleOwn.data && accessors.some(function (acc) {
    return moduleOwn[acc];
  })) {
  throw new Error('For VM objects, attribute data must not coexist with public, protected, or private. Please replace data with public.');
} else if (!moduleOwn.data) {
  moduleOwn.data = {};
  moduleOwn._descriptor = {};
  accessors.forEach(function(acc) {
    var accType = typeof moduleOwn[acc];
    if (accType === 'object') {
      moduleOwn.data = Object.assign(moduleOwn.data, moduleOwn[acc]);
      for (var name in moduleOwn[acc]) {
        moduleOwn._descriptor[name] = {access : acc};
      }
    } else if (accType === 'function') {
      console.warn('For VM objects, attribute ' + acc + ' value must not be a function. Change the value to an object.');
    }
  });
}}
/* generated by ace-loader */


/***/ }),

/***/ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\news\\news.js":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./lib/script.js!./node_modules/babel-loader/lib?presets[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/pages/news/news.js ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = function(module, exports, $app_require$){"use strict";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _newArrowCheck2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/newArrowCheck */ "./node_modules/@babel/runtime/helpers/newArrowCheck.js"));

var _system = _interopRequireDefault($app_require$("@app-module/system.router"));

var _system2 = _interopRequireDefault(systemplugin.fetch);

var _newsList = _interopRequireDefault(__webpack_require__(/*! ../../common/data/newsList.js */ "D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\data\\newsList.js"));

var _default = {
  data: {
    title: 'World',
    type: 'top',
    news: [{
      key: 'top',
      title: '头条',
      list: _newsList["default"].result.data
    }, {
      key: 'shehui',
      title: '社会',
      list: []
    }, {
      key: 'guonei',
      title: '国内',
      list: []
    }, {
      key: 'guoji',
      title: '国际',
      list: []
    }, {
      key: 'yule',
      title: '娱乐',
      list: []
    }, {
      key: 'tiyu',
      title: '体育',
      list: []
    }, {
      key: 'junshi',
      title: '军事',
      list: []
    }, {
      key: 'keji',
      title: '科技',
      list: []
    }, {
      key: 'caijing',
      title: '财经',
      list: []
    }, {
      key: 'shishang',
      title: '时尚',
      list: []
    }, {
      key: 'youxi',
      title: '游戏',
      list: []
    }, {
      key: 'qiche',
      title: '汽车',
      list: []
    }, {
      key: 'jiankang',
      title: '健康',
      list: []
    }]
  },
  onInit: function onInit() {
    console.log('News onInit');
    this.getNewsList();
  },
  onReady: function onReady() {
    console.log('News onReady');
  },
  onShow: function onShow() {
    console.log('News onShow');
  },
  onActive: function onActive() {
    console.log('News onActive');
  },
  onInactive: function onInactive() {
    console.log('News onInactive');
  },
  onHide: function onHide() {
    console.log('News onHide');
  },
  onDestroy: function onDestroy() {
    console.log('News onDestroy');
  },
  goBack: function goBack() {
    _system["default"].back();
  },
  getNewsList: function getNewsList() {
    var _this = this;

    var that = this;
    var api = 'http://v.juhe.cn/toutiao/index';

    _system2["default"].fetch({
      url: api + '?type=' + this.type + '&key=6d7ee8d88bd4fb137f5d20ce7066a700',
      method: 'GET',
      responseType: 'json',
      success: function success(res) {
        var _this2 = this;

        (0, _newArrowCheck2["default"])(this, _this);
        console.log('666666666: ' + JSON.stringify(res));

        if (res.code == 200) {
          var target = JSON.parse(res.data);
          this.news.forEach(function (item) {
            (0, _newArrowCheck2["default"])(this, _this2);

            if (item.key == this.type) {
              item.list = target.result.data;
            }
          }.bind(this));
        } else {
          console.log('查询新闻失败');
        }
      }.bind(this)
    });
  },
  change: function change(e) {
    console.log('Tab index: ' + e.index);
    this.type = this.news[e.index].key;
    this.getNewsList();
  },
  clickItem: function clickItem(uk) {
    _system["default"].push({
      uri: "pages/newsdetail/newsdetail",
      params: {
        uniquekey: uk
      }
    });
  }
};
exports["default"] = _default;
var moduleOwn = exports.default || module.exports;
var accessors = ['public', 'protected', 'private'];
if (moduleOwn.data && accessors.some(function (acc) {
    return moduleOwn[acc];
  })) {
  throw new Error('For VM objects, attribute data must not coexist with public, protected, or private. Please replace data with public.');
} else if (!moduleOwn.data) {
  moduleOwn.data = {};
  moduleOwn._descriptor = {};
  accessors.forEach(function(acc) {
    var accType = typeof moduleOwn[acc];
    if (accType === 'object') {
      moduleOwn.data = Object.assign(moduleOwn.data, moduleOwn[acc]);
      for (var name in moduleOwn[acc]) {
        moduleOwn._descriptor[name] = {access : acc};
      }
    } else if (accType === 'function') {
      console.warn('For VM objects, attribute ' + acc + ' value must not be a function. Change the value to an object.');
    }
  });
}}
/* generated by ace-loader */


/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/newArrowCheck.js":
/*!**************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/newArrowCheck.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _newArrowCheck(innerThis, boundThis) {
  if (innerThis !== boundThis) {
    throw new TypeError("Cannot instantiate an arrow function");
  }
}

module.exports = _newArrowCheck;

/***/ }),

/***/ "D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\data\\newsList.js":
/*!*******************************************************************************************!*\
  !*** D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/common/data/newsList.js ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var _default = {
  "reason": "success!",
  "result": {
    "stat": "1",
    "data": [{
      "uniquekey": "cc10d9ad667b6e8505761cfd845b7f2d",
      "title": "热心群众捡包 民警帮寻失主",
      "date": "2021-07-02 14:44:00",
      "category": "头条",
      "author_name": "消费日报网",
      "url": "https://mini.eastday.com/mobile/210702144426603765570.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/news/20210702/20210702144426_d41d8cd98f00b204e9800998ecf8427e_1_mwpm_03201609.jpeg",
      "is_content": "1"
    }, {
      "uniquekey": "a0096cab277b9fb82c7894e4591c0ce1",
      "title": "“守护孩童”系列之三：预防未成年人犯罪 从避免过早监禁与过度指责开始",
      "date": "2021-07-02 14:39:00",
      "category": "头条",
      "author_name": "中国网",
      "url": "https://mini.eastday.com/mobile/210702143935955718367.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/news/20210702/20210702143935_571eb926b3f7ac117fcb96393e102288_1_mwpm_03201609.jpeg",
      "thumbnail_pic_s02": "https://dfzximg02.dftoutiao.com/news/20210702/20210702143935_571eb926b3f7ac117fcb96393e102288_2_mwpm_03201609.jpeg",
      "thumbnail_pic_s03": "https://dfzximg02.dftoutiao.com/news/20210702/20210702143935_571eb926b3f7ac117fcb96393e102288_3_mwpm_03201609.jpeg",
      "is_content": "1"
    }, {
      "uniquekey": "c82116062c87d0afb647a35a20b8868d",
      "title": "巡特警支队六小时内成功侦破砸汽车玻璃盗窃财物案",
      "date": "2021-07-02 14:37:00",
      "category": "头条",
      "author_name": "黄河新闻网大同频道",
      "url": "https://mini.eastday.com/mobile/210702143756716966360.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/news/20210702/20210702143756_1398492db4a813089e6de650c0b80054_1_mwpm_03201609.jpeg",
      "is_content": "1"
    }, {
      "uniquekey": "46aef27acb2fc2b1feb319e4554936a7",
      "title": "暖闻｜为方便患糖尿病学生用药，江苏一高职院校连买两台冰箱",
      "date": "2021-07-02 14:30:00",
      "category": "头条",
      "author_name": "澎湃新闻",
      "url": "https://mini.eastday.com/mobile/210702143033965767054.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/news/20210702/20210702143033_89536565bb711c4b2c7cc322de32e3ee_1_mwpm_03201609.jpeg",
      "thumbnail_pic_s02": "https://dfzximg02.dftoutiao.com/news/20210702/20210702143033_89536565bb711c4b2c7cc322de32e3ee_2_mwpm_03201609.jpeg",
      "thumbnail_pic_s03": "https://dfzximg02.dftoutiao.com/news/20210702/20210702143033_89536565bb711c4b2c7cc322de32e3ee_3_mwpm_03201609.jpeg",
      "is_content": "1"
    }, {
      "uniquekey": "09778c05cd4885b1aba67b1c96a4e322",
      "title": "不忘初心跟党走，万鸽飞翔庆百年",
      "date": "2021-07-02 14:30:00",
      "category": "头条",
      "author_name": "新民晚报",
      "url": "https://mini.eastday.com/mobile/210702143033037787534.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/news/20210702/20210702143033_196dfa474ad6f0919856261e8f1c887b_1_mwpm_03201609.jpeg",
      "is_content": "1"
    }, {
      "uniquekey": "701c6ff1ab17d635effd3574c32c624d",
      "title": "江苏司机不敢过高架桥，向遵义交警“报警”求助",
      "date": "2021-07-02 14:27:00",
      "category": "头条",
      "author_name": "贵阳网",
      "url": "https://mini.eastday.com/mobile/210702142738948805607.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/news/20210702/20210702142738_8df5fba96bd071b004500f824013b44c_1_mwpm_03201609.jpeg",
      "thumbnail_pic_s02": "https://dfzximg02.dftoutiao.com/news/20210702/20210702142738_8df5fba96bd071b004500f824013b44c_2_mwpm_03201609.jpeg",
      "thumbnail_pic_s03": "https://dfzximg02.dftoutiao.com/news/20210702/20210702142738_8df5fba96bd071b004500f824013b44c_3_mwpm_03201609.jpeg",
      "is_content": "1"
    }, {
      "uniquekey": "a3c0265bf60ed21c779bedc14380ca82",
      "title": "监测报告公布：北京“90后”农民工更注重休息和自我提升",
      "date": "2021-07-02 14:00:00",
      "category": "头条",
      "author_name": "北京日报",
      "url": "https://mini.eastday.com/mobile/210702140016358250179.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/news/20210702/20210702140016_2b089755953e5caa8be773b832b62e76_1_mwpm_03201609.png",
      "thumbnail_pic_s02": "https://dfzximg02.dftoutiao.com/news/20210702/20210702140016_2b089755953e5caa8be773b832b62e76_2_mwpm_03201609.png",
      "thumbnail_pic_s03": "https://dfzximg02.dftoutiao.com/news/20210702/20210702140016_2b089755953e5caa8be773b832b62e76_3_mwpm_03201609.png",
      "is_content": "1"
    }, {
      "uniquekey": "db5ca6174f9a53fc8cdeda20cc01317e",
      "title": "网吧老板“抓”客人了，三个月大客户强行赶出去，网友：不容易",
      "date": "2021-07-02 13:49:00",
      "category": "头条",
      "author_name": "葱花儿教你做菜",
      "url": "https://mini.eastday.com/mobile/210702134951649989612.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/minimodify/20210702/587x636_60dea8ff3b282_mwpm_03201609.jpeg",
      "is_content": "1"
    }, {
      "uniquekey": "4f69c789b6daa789a5f5e62a353a79c9",
      "title": "庆祝大会9点改8点，印好的请柬咋办？“贴8”引来大批点赞",
      "date": "2021-07-02 13:45:00",
      "category": "头条",
      "author_name": "北京日报",
      "url": "https://mini.eastday.com/mobile/210702134501096573281.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/news/20210702/20210702134501_61326ee37f20c23278227566b5d48976_1_mwpm_03201609.jpeg",
      "thumbnail_pic_s02": "https://dfzximg02.dftoutiao.com/news/20210702/20210702134501_61326ee37f20c23278227566b5d48976_2_mwpm_03201609.png",
      "is_content": "1"
    }, {
      "uniquekey": "437435e113127cc6d5ff566b586691d5",
      "title": "看！北京天空中，太阳戴上了“光环”！",
      "date": "2021-07-02 13:29:00",
      "category": "头条",
      "author_name": "北京日报",
      "url": "https://mini.eastday.com/mobile/210702132956990316751.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/news/20210702/20210702132956_d1bd312623bd5d434c2ed1e667fbb5f7_1_mwpm_03201609.jpeg",
      "thumbnail_pic_s02": "https://dfzximg02.dftoutiao.com/news/20210702/20210702132956_d1bd312623bd5d434c2ed1e667fbb5f7_2_mwpm_03201609.jpeg",
      "thumbnail_pic_s03": "https://dfzximg02.dftoutiao.com/news/20210702/20210702132956_d1bd312623bd5d434c2ed1e667fbb5f7_3_mwpm_03201609.jpeg",
      "is_content": "1"
    }, {
      "uniquekey": "d6beadfb7e1464466f4da052fcf13540",
      "title": "吴春艳：冲锋在前，做学校坚强的“值守员”",
      "date": "2021-07-02 13:12:00",
      "category": "头条",
      "author_name": "福州新闻网",
      "url": "https://mini.eastday.com/mobile/210702131258054823691.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/news/20210702/20210702131258_d41d8cd98f00b204e9800998ecf8427e_1_mwpm_03201609.jpeg",
      "is_content": "1"
    }, {
      "uniquekey": "c6bc1b420cf0f96a7df02d59646bdb11",
      "title": "鸭绿河农场有限公司防汛抗旱应急演练 筑牢安全“防护网”",
      "date": "2021-07-02 13:07:00",
      "category": "头条",
      "author_name": "东北网",
      "url": "https://mini.eastday.com/mobile/210702130754328336805.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/news/20210702/20210702130754_d2c29d158e2160c5fd051deec53664ba_1_mwpm_03201609.jpeg",
      "is_content": "1"
    }, {
      "uniquekey": "40acb3aca75a4cbfce46f129adc469ab",
      "title": "圣商教育派优秀老师为该县企业家讲课",
      "date": "2021-07-02 12:21:00",
      "category": "头条",
      "author_name": "瞭望民生",
      "url": "https://mini.eastday.com/mobile/210702122120883353729.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/minimodify/20210702/400x300_60de944011661_mwpm_03201609.png",
      "is_content": "1"
    }, {
      "uniquekey": "3e1ad9ede299bb9752179b9f5d3ed89e",
      "title": "兰考：袁忠学故乡情书画作品捐赠展在县文化馆举办",
      "date": "2021-07-02 11:33:00",
      "category": "头条",
      "author_name": "消费日报网",
      "url": "https://mini.eastday.com/mobile/210702113319911550722.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/news/20210702/20210702113319_d41d8cd98f00b204e9800998ecf8427e_1_mwpm_03201609.jpeg",
      "thumbnail_pic_s02": "https://dfzximg02.dftoutiao.com/news/20210702/20210702113319_d41d8cd98f00b204e9800998ecf8427e_2_mwpm_03201609.jpeg",
      "thumbnail_pic_s03": "https://dfzximg02.dftoutiao.com/news/20210702/20210702113319_d41d8cd98f00b204e9800998ecf8427e_3_mwpm_03201609.jpeg",
      "is_content": "1"
    }, {
      "uniquekey": "9a7012592bce702a89e57b59f0efb610",
      "title": "首都机场安保公司马紫薇——首都机场，一点一滴",
      "date": "2021-07-02 11:32:00",
      "category": "头条",
      "author_name": "消费日报网",
      "url": "https://mini.eastday.com/mobile/210702113214263515084.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/news/20210702/20210702113214_d41d8cd98f00b204e9800998ecf8427e_1_mwpm_03201609.jpeg",
      "is_content": "1"
    }, {
      "uniquekey": "85982b8a287d8f148574fff8f3d54f6f",
      "title": "苏州稻香村鲜肉月饼咸香上市 观前街店排起长队",
      "date": "2021-07-02 11:29:00",
      "category": "头条",
      "author_name": "消费日报网",
      "url": "https://mini.eastday.com/mobile/210702112946142887927.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/news/20210702/20210702112946_d41d8cd98f00b204e9800998ecf8427e_1_mwpm_03201609.jpeg",
      "thumbnail_pic_s02": "https://dfzximg02.dftoutiao.com/news/20210702/20210702112946_d41d8cd98f00b204e9800998ecf8427e_2_mwpm_03201609.jpeg",
      "thumbnail_pic_s03": "https://dfzximg02.dftoutiao.com/news/20210702/20210702112946_d41d8cd98f00b204e9800998ecf8427e_3_mwpm_03201609.jpeg",
      "is_content": "1"
    }, {
      "uniquekey": "65dccbff45761b5af5abc62708b5f431",
      "title": "舞剧《永不消逝的电波》七一在京献演 计划7月驻沪演出百场",
      "date": "2021-07-02 11:28:00",
      "category": "头条",
      "author_name": "东方网",
      "url": "https://mini.eastday.com/mobile/210702112852758351339.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/news/20210702/20210702112852_9811ecc4ccb72819c8fc6bf68f07db10_1_mwpm_03201609.png",
      "thumbnail_pic_s02": "https://dfzximg02.dftoutiao.com/news/20210702/20210702112852_9811ecc4ccb72819c8fc6bf68f07db10_2_mwpm_03201609.jpeg",
      "thumbnail_pic_s03": "https://dfzximg02.dftoutiao.com/news/20210702/20210702112852_9811ecc4ccb72819c8fc6bf68f07db10_3_mwpm_03201609.png",
      "is_content": "1"
    }, {
      "uniquekey": "ab66e3a9bf3a0c335335db50136bae15",
      "title": "高三毕业生扎堆做近视手术 医生提醒:并非人人可做",
      "date": "2021-07-02 11:27:00",
      "category": "头条",
      "author_name": "厦门网",
      "url": "https://mini.eastday.com/mobile/210702112749563337460.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/news/20210702/20210702112749_a1c61ee68dea7ee91f538e265624d286_1_mwpm_03201609.jpeg",
      "is_content": "1"
    }, {
      "uniquekey": "a19b1ed8efb5302c57840df8dad2ca56",
      "title": "\"美人鱼\"多了 时尚潜水运动兴起 连男士小孩都来学",
      "date": "2021-07-02 11:25:00",
      "category": "头条",
      "author_name": "厦门网",
      "url": "https://mini.eastday.com/mobile/210702112540052724746.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/news/20210702/20210702112540_8653796e003c41df5f13fddddded1700_1_mwpm_03201609.jpeg",
      "thumbnail_pic_s02": "https://dfzximg02.dftoutiao.com/news/20210702/20210702112540_8653796e003c41df5f13fddddded1700_2_mwpm_03201609.jpeg",
      "is_content": "1"
    }, {
      "uniquekey": "54f8f917f3b84e39396cecfbed7b7816",
      "title": "义诊送健康！暖心服务送到民警身边",
      "date": "2021-07-02 11:13:00",
      "category": "头条",
      "author_name": "北京昌平官方发布",
      "url": "https://mini.eastday.com/mobile/210702111349848684421.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/news/20210702/20210702111349_5fe0a4ee354ed5c722ef4bd6beb91d5e_1_mwpm_03201609.jpeg",
      "is_content": "1"
    }, {
      "uniquekey": "e07976d9ef212df14ac08cbd233435f3",
      "title": "雨花区试水地铁口“2分钟限时停车”",
      "date": "2021-07-02 11:09:00",
      "category": "头条",
      "author_name": "星辰在线",
      "url": "https://mini.eastday.com/mobile/210702110959020165788.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/news/20210702/20210702110959_99f9b4527152f904a9d2652cc5918e01_1_mwpm_03201609.jpeg",
      "is_content": "0"
    }, {
      "uniquekey": "92815333cfebb6f32d2ec5ab4c4d26bf",
      "title": "仲景宛西制药“讲经典，卫健康”走进天府之国四川一心堂",
      "date": "2021-07-02 10:50:00",
      "category": "头条",
      "author_name": "消费日报网",
      "url": "https://mini.eastday.com/mobile/210702105051302187684.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/news/20210702/20210702105051_d41d8cd98f00b204e9800998ecf8427e_1_mwpm_03201609.jpeg",
      "thumbnail_pic_s02": "https://dfzximg02.dftoutiao.com/news/20210702/20210702105051_d41d8cd98f00b204e9800998ecf8427e_2_mwpm_03201609.jpeg",
      "thumbnail_pic_s03": "https://dfzximg02.dftoutiao.com/news/20210702/20210702105051_d41d8cd98f00b204e9800998ecf8427e_3_mwpm_03201609.jpeg",
      "is_content": "1"
    }, {
      "uniquekey": "8d09d4ade130c9f29fab73058a75e5d5",
      "title": "衡南轮椅女孩谢可欣：用奋斗唱响圆梦之歌",
      "date": "2021-07-02 10:46:00",
      "category": "头条",
      "author_name": "大公湖南",
      "url": "https://mini.eastday.com/mobile/210702104601226608371.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/news/20210702/20210702104601_d41d8cd98f00b204e9800998ecf8427e_1_mwpm_03201609.jpeg",
      "thumbnail_pic_s02": "https://dfzximg02.dftoutiao.com/news/20210702/20210702104601_d41d8cd98f00b204e9800998ecf8427e_2_mwpm_03201609.jpeg",
      "thumbnail_pic_s03": "https://dfzximg02.dftoutiao.com/news/20210702/20210702104601_d41d8cd98f00b204e9800998ecf8427e_3_mwpm_03201609.jpeg",
      "is_content": "1"
    }, {
      "uniquekey": "716aa827554d4baa76ac67cde5dfb7fe",
      "title": "“辛苦我一人，洁净千万家”，人民日报刊发时传祥孙女感言",
      "date": "2021-07-02 10:45:00",
      "category": "头条",
      "author_name": "人民网-人民日报",
      "url": "https://mini.eastday.com/mobile/210702104508788644176.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/news/20210702/20210702104508_14b1c2079ed475e37eb356d2d6a62d51_1_mwpm_03201609.jpeg",
      "is_content": "1"
    }, {
      "uniquekey": "e277e3df7c002c337c94713650216d10",
      "title": "七一勋章获得者吕其明：一生只做一件事 为祖国和人民创作",
      "date": "2021-07-02 10:28:00",
      "category": "头条",
      "author_name": "东方网",
      "url": "https://mini.eastday.com/mobile/210702102813883534703.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/news/20210702/20210702102813_05637ea602bf6b9b2ecee021edada7bf_1_mwpm_03201609.jpeg",
      "thumbnail_pic_s02": "https://dfzximg02.dftoutiao.com/news/20210702/20210702102813_05637ea602bf6b9b2ecee021edada7bf_2_mwpm_03201609.jpeg",
      "thumbnail_pic_s03": "https://dfzximg02.dftoutiao.com/news/20210702/20210702102813_05637ea602bf6b9b2ecee021edada7bf_3_mwpm_03201609.jpeg",
      "is_content": "1"
    }, {
      "uniquekey": "3c7c2937d2646aa9aa00b1b7efd54e6a",
      "title": "精锐教育老师教学生知识，关心学生成长，引导学生走向正确的道路",
      "date": "2021-07-02 10:27:00",
      "category": "头条",
      "author_name": "消费日报网综合",
      "url": "https://mini.eastday.com/mobile/210702102726067342298.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/news/20210702/20210702102726_d41d8cd98f00b204e9800998ecf8427e_1_mwpm_03201609.png",
      "is_content": "1"
    }, {
      "uniquekey": "f9c5387a62694a8a2f73779750c3c279",
      "title": "把坚守初心写在信仰的旗帜上",
      "date": "2021-07-02 09:06:00",
      "category": "头条",
      "author_name": "云南网",
      "url": "https://mini.eastday.com/mobile/210702090657922185893.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/news/20210702/20210702090657_d41d8cd98f00b204e9800998ecf8427e_1_mwpm_03201609.jpeg",
      "thumbnail_pic_s02": "https://dfzximg02.dftoutiao.com/news/20210702/20210702090657_d41d8cd98f00b204e9800998ecf8427e_2_mwpm_03201609.jpeg",
      "thumbnail_pic_s03": "https://dfzximg02.dftoutiao.com/news/20210702/20210702090657_d41d8cd98f00b204e9800998ecf8427e_3_mwpm_03201609.jpeg",
      "is_content": "1"
    }, {
      "uniquekey": "3d5b5720ad561b8723f2cee069fd5dde",
      "title": "“只有前进，没有后退”（奋斗百年路 启航新征程·“七一勋章”获得者）",
      "date": "2021-07-02 08:14:00",
      "category": "头条",
      "author_name": "人民网－人民日报",
      "url": "https://mini.eastday.com/mobile/210702081443507719916.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/news/20210702/20210702081443_1a2ddf79a6543d6cd0c2be1fcd3b567f_1_mwpm_03201609.jpeg",
      "is_content": "1"
    }, {
      "uniquekey": "51f71a59134c5714033c35dfccc29088",
      "title": "宏仁堂医药连锁携手新华制药开启工业红色基因传承活动",
      "date": "2021-07-02 07:53:00",
      "category": "头条",
      "author_name": "夕阳红似火",
      "url": "https://mini.eastday.com/mobile/210702075348892844625.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/minimodify/20210702/2592x1728_60de558c62ec2_mwpm_03201609.jpeg",
      "is_content": "1"
    }, {
      "uniquekey": "028502aa962a51bf5f2a10acd3df67bd",
      "title": "定安策划推出10集《琼剧唱党史》系列短片 庆祝建党100周年",
      "date": "2021-07-02 00:12:00",
      "category": "头条",
      "author_name": "南海网",
      "url": "https://mini.eastday.com/mobile/210702001215046771742.html",
      "thumbnail_pic_s": "https://dfzximg02.dftoutiao.com/news/20210702/20210702001215_46c0ba6ef9f608c21c3cec7f13e12eea_1_mwpm_03201609.jpeg",
      "thumbnail_pic_s02": "https://dfzximg02.dftoutiao.com/news/20210702/20210702001215_46c0ba6ef9f608c21c3cec7f13e12eea_2_mwpm_03201609.jpeg",
      "is_content": "1"
    }],
    "page": "1",
    "pageSize": "30"
  },
  "error_code": 0
};
exports["default"] = _default;

/***/ }),

/***/ "D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\news\\news.hml?entry":
/*!*********************************************************************************************!*\
  !*** D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/pages/news/news.hml?entry ***!
  \*********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(/*! !./lib/loader.js!../../common/components/bottomNav/index.hml?name=bottomnav */ "./lib/loader.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\components\\bottomNav\\index.hml?name=bottomnav")
var $app_template$ = __webpack_require__(/*! !./lib/json.js!./lib/template.js!./news.hml */ "./lib/json.js!./lib/template.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\news\\news.hml")
var $app_style$ = __webpack_require__(/*! !./lib/json.js!./lib/style.js!./news.css */ "./lib/json.js!./lib/style.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\news\\news.css")
var $app_script$ = __webpack_require__(/*! !./lib/script.js!./node_modules/babel-loader?presets[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!./news.js */ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\news\\news.js")

$app_define$('@app-component/news', [], function($app_require$, $app_exports$, $app_module$) {

$app_script$($app_module$, $app_exports$, $app_require$)
if ($app_exports$.__esModule && $app_exports$.default) {
$app_module$.exports = $app_exports$.default
}

$app_module$.exports.template = $app_template$

$app_module$.exports.style = $app_style$

})
$app_bootstrap$('@app-component/news',undefined,undefined)

/***/ })

/******/ });