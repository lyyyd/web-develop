/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\component\\container\\swiper\\index.hml?entry");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./lib/json.js!./lib/style.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\component\\container\\swiper\\index.css":
/*!*******************************************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/style.js!D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/pages/component/container/swiper/index.css ***!
  \*******************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  ".container": {
    "display": "flex",
    "flexDirection": "column",
    "justifyContent": "flex-start",
    "alignItems": "center",
    "left": "0px",
    "top": "0px"
  },
  ".title": {
    "fontSize": "30px",
    "textAlign": "center",
    "width": "200px",
    "height": "50px"
  },
  ".swiper": {
    "flexDirection": "column",
    "alignContent": "center",
    "alignItems": "center",
    "width": "100%",
    "height": "200px",
    "borderTopWidth": "1px",
    "borderRightWidth": "1px",
    "borderBottomWidth": "1px",
    "borderLeftWidth": "1px",
    "borderTopStyle": "solid",
    "borderRightStyle": "solid",
    "borderBottomStyle": "solid",
    "borderLeftStyle": "solid",
    "borderTopColor": "#000000",
    "borderRightColor": "#000000",
    "borderBottomColor": "#000000",
    "borderLeftColor": "#000000",
    "indicatorColor": "#cf2411",
    "indicatorSize": "14px",
    "indicatorBottom": "20px",
    "indicatorRight": "30px",
    "marginTop": "100px"
  },
  ".swiperContent": {
    "height": "100%",
    "justifyContent": "center"
  },
  ".button": {
    "width": "70%",
    "marginTop": "10px",
    "marginRight": "10px",
    "marginBottom": "10px",
    "marginLeft": "10px"
  },
  ".text": {
    "fontSize": "40px"
  }
}

/***/ }),

/***/ "./lib/json.js!./lib/template.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\component\\container\\swiper\\index.hml":
/*!**********************************************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/template.js!D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/pages/component/container/swiper/index.hml ***!
  \**********************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  "attr": {
    "debugLine": "pages/component/container/swiper/index:1",
    "className": "container"
  },
  "type": "div",
  "classList": [
    "container"
  ],
  "children": [
    {
      "attr": {
        "debugLine": "pages/component/container/swiper/index:2",
        "className": "title",
        "value": function () {return this.title}
      },
      "type": "text",
      "classList": [
        "title"
      ]
    },
    {
      "attr": {
        "debugLine": "pages/component/container/swiper/index:5",
        "className": "swiper",
        "id": "swiper",
        "index": "0",
        "indicator": "true",
        "loop": "true",
        "digital": "false",
        "autoplay": "true",
        "vertical": "true"
      },
      "type": "swiper",
      "classList": [
        "swiper"
      ],
      "id": "swiper",
      "children": [
        {
          "attr": {
            "debugLine": "pages/component/container/swiper/index:14",
            "className": "swiperContent"
          },
          "type": "div",
          "classList": [
            "swiperContent"
          ],
          "children": [
            {
              "attr": {
                "debugLine": "pages/component/container/swiper/index:15",
                "src": "/common/images/bg-tv.jpg"
              },
              "type": "image"
            }
          ]
        },
        {
          "attr": {
            "debugLine": "pages/component/container/swiper/index:17",
            "className": "swiperContent"
          },
          "type": "div",
          "classList": [
            "swiperContent"
          ],
          "children": [
            {
              "attr": {
                "debugLine": "pages/component/container/swiper/index:18",
                "src": "/common/images/wall.jpg"
              },
              "type": "image"
            }
          ]
        },
        {
          "attr": {
            "debugLine": "pages/component/container/swiper/index:20",
            "className": "swiperContent"
          },
          "type": "div",
          "classList": [
            "swiperContent"
          ],
          "children": [
            {
              "attr": {
                "debugLine": "pages/component/container/swiper/index:21",
                "src": "/common/images/sky.jpg"
              },
              "type": "image"
            }
          ]
        }
      ]
    },
    {
      "attr": {
        "debugLine": "pages/component/container/swiper/index:24",
        "className": "button",
        "type": "button",
        "value": "swipeTo"
      },
      "type": "input",
      "classList": [
        "button"
      ],
      "events": {
        "click": "swipeTo"
      }
    },
    {
      "attr": {
        "debugLine": "pages/component/container/swiper/index:25",
        "className": "button",
        "type": "button",
        "value": "showNext"
      },
      "type": "input",
      "classList": [
        "button"
      ],
      "events": {
        "click": "showNext"
      }
    },
    {
      "attr": {
        "debugLine": "pages/component/container/swiper/index:26",
        "className": "button",
        "type": "button",
        "value": "showPrevious"
      },
      "type": "input",
      "classList": [
        "button"
      ],
      "events": {
        "click": "showPrevious"
      }
    }
  ]
}

/***/ }),

/***/ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\component\\container\\swiper\\index.js":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./lib/script.js!./node_modules/babel-loader/lib?presets[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/pages/component/container/swiper/index.js ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function(module, exports, $app_require$){"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var _default = {
  data: {
    title: 'Swiper'
  },
  swipeTo: function swipeTo() {
    this.$element('swiper').swipeTo({
      index: 2
    });
  },
  showNext: function showNext() {
    this.$element('swiper').showNext();
  },
  showPrevious: function showPrevious() {
    this.$element('swiper').showPrevious();
  }
};
exports["default"] = _default;
var moduleOwn = exports.default || module.exports;
var accessors = ['public', 'protected', 'private'];
if (moduleOwn.data && accessors.some(function (acc) {
    return moduleOwn[acc];
  })) {
  throw new Error('For VM objects, attribute data must not coexist with public, protected, or private. Please replace data with public.');
} else if (!moduleOwn.data) {
  moduleOwn.data = {};
  moduleOwn._descriptor = {};
  accessors.forEach(function(acc) {
    var accType = typeof moduleOwn[acc];
    if (accType === 'object') {
      moduleOwn.data = Object.assign(moduleOwn.data, moduleOwn[acc]);
      for (var name in moduleOwn[acc]) {
        moduleOwn._descriptor[name] = {access : acc};
      }
    } else if (accType === 'function') {
      console.warn('For VM objects, attribute ' + acc + ' value must not be a function. Change the value to an object.');
    }
  });
}}
/* generated by ace-loader */


/***/ }),

/***/ "D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\component\\container\\swiper\\index.hml?entry":
/*!********************************************************************************************************************!*\
  !*** D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/pages/component/container/swiper/index.hml?entry ***!
  \********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $app_template$ = __webpack_require__(/*! !./lib/json.js!./lib/template.js!./index.hml */ "./lib/json.js!./lib/template.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\component\\container\\swiper\\index.hml")
var $app_style$ = __webpack_require__(/*! !./lib/json.js!./lib/style.js!./index.css */ "./lib/json.js!./lib/style.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\component\\container\\swiper\\index.css")
var $app_script$ = __webpack_require__(/*! !./lib/script.js!./node_modules/babel-loader?presets[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!./index.js */ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\component\\container\\swiper\\index.js")

$app_define$('@app-component/index', [], function($app_require$, $app_exports$, $app_module$) {

$app_script$($app_module$, $app_exports$, $app_require$)
if ($app_exports$.__esModule && $app_exports$.default) {
$app_module$.exports = $app_exports$.default
}

$app_module$.exports.template = $app_template$

$app_module$.exports.style = $app_style$

})
$app_bootstrap$('@app-component/index',undefined,undefined)

/***/ })

/******/ });