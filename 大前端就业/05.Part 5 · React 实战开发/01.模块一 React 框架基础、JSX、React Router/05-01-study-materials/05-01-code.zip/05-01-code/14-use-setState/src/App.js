import Header from './Header'

function App() {
  return (
    <div>
      <Header />
    </div>
  )
}

export default App
