import Layout from './Layout'

function List() {
  return (
    <Layout>
      <p>当前是List界面</p>
    </Layout>
  )
}

export default List