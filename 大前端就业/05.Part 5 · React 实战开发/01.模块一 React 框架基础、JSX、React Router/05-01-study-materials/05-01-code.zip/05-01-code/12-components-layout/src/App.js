import Home from './components/Home'
import List from './components/List'

function App() {
  return (
    <List />
  )
}

export default App
