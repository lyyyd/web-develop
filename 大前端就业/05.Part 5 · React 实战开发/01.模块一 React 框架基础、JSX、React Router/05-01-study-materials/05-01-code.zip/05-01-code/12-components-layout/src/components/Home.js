import Layout from './Layout'

function Home() {
  return (
    <Layout>
      <p>当前是home界面</p>
    </Layout>
  )
}

export default Home