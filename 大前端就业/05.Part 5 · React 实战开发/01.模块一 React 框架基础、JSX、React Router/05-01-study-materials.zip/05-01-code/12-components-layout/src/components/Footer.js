function Footer() {
  return (
    <>
      <div className={'footer'}>Footer组件</div>
    </>
  )
}

export default Footer