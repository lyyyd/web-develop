import React from 'react'

function About ({name, age}) {
  return (
    <div>
      <p>{name}</p>
      <p>{age}</p>
    </div>
  )
}

export default About 

