import React, {Component, Fragment} from 'react'

class About extends Component{
  render(){
    return(
      <>About中的内容</>
    )
  }
}

export default About

