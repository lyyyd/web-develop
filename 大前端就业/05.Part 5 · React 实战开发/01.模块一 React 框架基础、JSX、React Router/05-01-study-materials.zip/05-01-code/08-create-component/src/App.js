import About from "./About";

/**
 *  一、创建函数组件 
 * 
 *  二、创建类组件
 *  01 必须继承 Component render 
 *  02 组件名称的首字母必须是大写的，在 React 当中可以用于区分组件和普通的标记 
 *  03 
 */


function App() {
  return(
    <div>
      <About />
    </div>
  )
}

export default App
