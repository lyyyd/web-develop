export default function Custom404 () {
  return <div>404</div>;
}