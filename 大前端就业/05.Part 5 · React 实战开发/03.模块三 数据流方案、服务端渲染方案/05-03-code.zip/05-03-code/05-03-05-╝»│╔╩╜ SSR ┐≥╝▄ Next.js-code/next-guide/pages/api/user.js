export default (req, res) => {
  res.send({name: "张三", age: 20});
}