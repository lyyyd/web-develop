import { createAction } from "redux-actions"

export const get_products = createAction("get_products")
export const get_products_success = createAction("get_products_success")
