import { createAction } from "redux-actions"

export const search_products = createAction("search_products")
export const search_products_success = createAction("search_products_success")
