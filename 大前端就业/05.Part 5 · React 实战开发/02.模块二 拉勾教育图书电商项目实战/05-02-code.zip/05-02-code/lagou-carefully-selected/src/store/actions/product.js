import { createAction } from "redux-actions"

export const get_product_by_id = createAction("get_product_by_id")
export const get_product_by_id_success = createAction(
  "get_product_by_id_success"
)
