import { createAction } from "redux-actions"

export const filter_products = createAction("filter_products")
export const filter_products_success = createAction("filter_products_success")
