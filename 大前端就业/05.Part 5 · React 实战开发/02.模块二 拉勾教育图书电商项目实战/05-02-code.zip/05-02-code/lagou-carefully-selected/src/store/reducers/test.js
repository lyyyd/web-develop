export default function testReducer(state = 0) {
  return state
}
