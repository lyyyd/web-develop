import { API } from "./config"

function App() {
  return <div>App works</div>
}

console.log(API)

export default App
