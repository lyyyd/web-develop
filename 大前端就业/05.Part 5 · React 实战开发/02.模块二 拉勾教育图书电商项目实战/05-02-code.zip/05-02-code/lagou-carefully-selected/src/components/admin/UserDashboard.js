import Layout from "../core/Layout"

function UserDashboard() {
  return <Layout title="用户 Dashboard"></Layout>
}

export default UserDashboard
