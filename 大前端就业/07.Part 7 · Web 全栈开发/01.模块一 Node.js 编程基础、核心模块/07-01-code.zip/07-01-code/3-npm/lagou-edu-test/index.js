function add(n1, n2) {
  return n1 + n2
}

function test() {
  console.log("test")
}

module.exports.add = add
