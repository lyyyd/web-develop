module.exports = {
  root: "server/app.js"
}
