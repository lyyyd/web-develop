module.exports = {
  root: "server/index.js"
}
