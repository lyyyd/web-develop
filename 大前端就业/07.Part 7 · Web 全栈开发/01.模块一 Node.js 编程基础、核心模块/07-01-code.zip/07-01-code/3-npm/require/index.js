const server = require("server")
console.log(server)
