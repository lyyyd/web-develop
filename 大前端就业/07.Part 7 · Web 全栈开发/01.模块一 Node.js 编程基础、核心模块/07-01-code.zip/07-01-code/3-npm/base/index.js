const _ = require("lodash")
const lagouEduTest = require("lagou-edu-test")

const array = ["a", "b", "c", "d"]
console.log(_.chunk(array, 2))
console.log(lagouEduTest.add(1, 2))
