const url = "http://www.example.com"

function log(message) {
  console.log(message)
}

console.log(__filename)
console.log(__dirname)

// exports.endPoint = url
// exports.log = log

exports = {
  endPoint: url,
  log: log
}
