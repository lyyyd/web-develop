const fs = require("fs")

const result = fs.readdirSync("./")

fs.readdir("./", function (error, files) {
  console.log(files)
})
