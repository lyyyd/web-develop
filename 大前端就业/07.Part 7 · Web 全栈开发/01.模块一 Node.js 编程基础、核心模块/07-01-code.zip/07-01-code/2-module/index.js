const logger = require("./logger")
console.log(logger)
console.log(logger.endPoint)
