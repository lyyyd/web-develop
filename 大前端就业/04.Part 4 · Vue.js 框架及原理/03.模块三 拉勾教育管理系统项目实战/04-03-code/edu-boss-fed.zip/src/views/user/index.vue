<template>
  <div class="user">
    <user-list></user-list>
  </div>
</template>

<script>
import UserList from './components/List'

export default {
  name: 'UserIndex',
  components: {
    UserList
  }
}
</script>

<style lang="scss" scoped></style>
