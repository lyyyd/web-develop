<template>
  <div class="advert-space">广告位管理</div>
</template>

<script>
export default {
  name: 'AdvertSpaceIndex'
}
</script>

<style lang="scss" scoped></style>
