<template>
  <div class="resource">
    <resource-list></resource-list>
  </div>
</template>

<script>
import ResourceList from './components/List'
export default {
  name: 'ResourceIndex',
  components: {
    ResourceList
  }
}
</script>

<style lang="scss" scoped></style>
