<template>
  <div class="role">
    <role-list></role-list>
  </div>
</template>

<script>
import RoleList from './components/List'

export default {
  name: 'LoginIndex',
  components: {
    RoleList
  }
}
</script>

<style lang="scss" scoped></style>
