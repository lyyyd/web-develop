<template>
  <div class="advert">广告管理</div>
</template>

<script>
export default {
  name: 'AdvertIndex'
}
</script>

<style lang="scss" scoped></style>
