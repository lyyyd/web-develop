function foo(ms: string): void{
  console.log(msg);
  
}

foo("hello typescript~")