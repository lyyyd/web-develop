
function fn () {
  console.log('hello')

  console.log('eslint')
}

fn()
