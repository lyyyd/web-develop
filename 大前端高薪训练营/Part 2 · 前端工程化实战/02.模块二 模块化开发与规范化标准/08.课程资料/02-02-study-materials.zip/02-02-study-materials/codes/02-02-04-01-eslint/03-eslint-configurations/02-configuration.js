// document.getElementById("#abc")

// alert(11)
// const foo = 1
// let foo2 = 2
// let a = new Promise()

// alert(11) 

jQuery("#abc")