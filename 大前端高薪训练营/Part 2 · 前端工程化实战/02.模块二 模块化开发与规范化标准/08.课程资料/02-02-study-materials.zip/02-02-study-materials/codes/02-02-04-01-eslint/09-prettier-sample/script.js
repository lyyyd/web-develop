(function () {
  function greeting(msg) {
    console.log(msg);
  }
  var text = "hello prettier";
  greeting(text);
})();
