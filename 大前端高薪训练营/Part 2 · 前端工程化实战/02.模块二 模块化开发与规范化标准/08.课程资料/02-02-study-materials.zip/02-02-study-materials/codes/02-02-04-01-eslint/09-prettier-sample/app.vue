<template>
  <div>
    <h1>{{ title }}</h1>
  </div>
</template>

<script>
export default {
  data() {
    return { title: "Vue Prettier" };
  },
};
</script>

<style>
div {
  color: #000;
}
</style>
