export var foo = 'bar'
