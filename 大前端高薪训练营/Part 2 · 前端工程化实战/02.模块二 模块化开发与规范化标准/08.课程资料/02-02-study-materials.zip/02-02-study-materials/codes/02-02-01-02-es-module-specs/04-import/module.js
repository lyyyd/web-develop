var name = 'jack'
var age = 18

export { name, age }

console.log('module action')

export default 'default export'
