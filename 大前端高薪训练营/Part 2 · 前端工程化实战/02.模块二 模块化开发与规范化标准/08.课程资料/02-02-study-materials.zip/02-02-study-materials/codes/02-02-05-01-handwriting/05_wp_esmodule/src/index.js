import name, { age } from './login.js'

console.log('index.js内容加载了')

console.log(name, '---->', age)
