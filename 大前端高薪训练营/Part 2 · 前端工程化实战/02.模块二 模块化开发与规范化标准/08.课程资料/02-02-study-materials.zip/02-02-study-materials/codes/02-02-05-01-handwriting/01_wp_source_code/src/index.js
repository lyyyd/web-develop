console.log('index.js内容')

module.exports = '入口文件导出内容'
