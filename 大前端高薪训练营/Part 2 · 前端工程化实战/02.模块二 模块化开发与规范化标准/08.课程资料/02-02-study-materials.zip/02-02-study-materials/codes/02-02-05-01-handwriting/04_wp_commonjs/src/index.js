let obj = require('./login.js')

console.log('index.js内容执行了')

console.log(obj.default, '---->', obj.age)
