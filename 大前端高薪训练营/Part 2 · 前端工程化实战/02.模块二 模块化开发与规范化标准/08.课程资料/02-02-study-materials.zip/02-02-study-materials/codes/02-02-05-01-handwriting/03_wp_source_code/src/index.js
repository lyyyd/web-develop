let name = require('./login.js')

console.log('index.js内容执行了')
console.log(name)
