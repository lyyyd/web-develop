let name = require('./login.js')

console.log('index.js执行')

console.log(name)
