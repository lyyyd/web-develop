// module.exports = '拉勾教育'

export default 'zce是一个帅哥'
export const age = 40