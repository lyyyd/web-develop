// 01 采用 cms 导出模块内容
// module.exports = 'zce'

// 02 采用 esModule 导出模块
export default '拉勾教育'
export const age = 100
