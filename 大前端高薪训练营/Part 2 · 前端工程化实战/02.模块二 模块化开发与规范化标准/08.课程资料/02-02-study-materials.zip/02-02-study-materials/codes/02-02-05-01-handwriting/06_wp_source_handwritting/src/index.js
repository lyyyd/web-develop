import name, { age } from './login.js'

console.log('index.js 执行了')

console.log(name, '<------')
console.log(age, '<------')
