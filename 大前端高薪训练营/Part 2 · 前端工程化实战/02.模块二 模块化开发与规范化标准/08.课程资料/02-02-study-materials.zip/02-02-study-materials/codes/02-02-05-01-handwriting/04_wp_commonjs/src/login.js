// 01 采用 cms 
// module.exports = '拉勾教育'

// 02 采用 esm 导出内容
export default 'zcegg'
export const age = 18

