export default level => {
  return document.createElement('h' + level)
}
