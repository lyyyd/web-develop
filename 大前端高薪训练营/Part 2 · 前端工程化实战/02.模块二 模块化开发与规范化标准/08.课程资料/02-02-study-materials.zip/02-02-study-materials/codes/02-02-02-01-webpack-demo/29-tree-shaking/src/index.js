import { Button } from './components'

document.body.appendChild(Button())
