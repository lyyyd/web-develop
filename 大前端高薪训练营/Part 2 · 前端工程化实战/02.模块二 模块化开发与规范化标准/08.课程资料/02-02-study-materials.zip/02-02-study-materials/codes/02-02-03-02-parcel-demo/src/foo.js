export default {
  bar: () => {
    console.log('hello parcel~')
  }
}
