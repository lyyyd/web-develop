module.exports = {
  foo: 'bar'
}
