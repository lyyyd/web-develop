export default {
  INCREMENT: state => {
    state.count++
  },
  DECREMENT: state => {
    state.count--
  }
}
