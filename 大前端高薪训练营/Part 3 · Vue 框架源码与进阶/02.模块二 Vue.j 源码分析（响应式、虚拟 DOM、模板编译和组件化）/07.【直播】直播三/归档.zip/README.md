# 20200827 直播

## CAZ 脚手架开发

> 参考链接：https://github.com/zce/caz

### CAZ 相关介绍

一个基于模板机制的脚手架工具。

### 基本使用

用指定模板创建一个新项目。

```shell
$ caz <template> [project] [-f|--force] [-o|--offline]

# caz with an official template
$ caz <template> [project]

# caz with a github repo
$ caz <owner>/<repo> [project]
```

如果并不是高频次的使用，我建议使用 npx 执行 caz 模块

```shell
$ npx caz <template> [project] [-f|--force] [-o|--offline]
```

#### 命令行选项

- `-f, --force`: 如果存在目标路径，先删除（慎用）
- `-o, --offline`: 尝试使用缓存中的模板

### 本地模板

除了使用 GitHub 上托管的模板，你还可以使用本地的模板

```shell
$ caz ~/local/template my-project
```

### 任意 URL 地址下载模板

```shell
$ caz https://cdn.zce.me/boilerplate.zip my-project
```

### 基于 CAZ 的模板开发

### 基于 CAZ 的脚手架工具开发

## CAZ 源码分析

核心代码基于 [zce/mwa](https://github.com/zce/mwa) 提供的中间件机制。

核心关键步骤：

- [confirm] - 确认目标路径是否是可用（不存在或者空目录）。
- [resolve] - 从远程（下载后解压）或者本地路径得到一个模板文件夹。
- [load] - 以 require 的方式加载模板中的配置信息。
- [inquire] - 根据模板配置中的问题，以命令行交互的方式询问用户一些问题。
- [setup] - 调用模板配置中的 setup 钩子函数（生命周期）。
- [prepare] - 加载模板文件夹中所有需要生成的文件，同时触发 prepare 钩子。
- [rename] - 根据用户输入的数据重命名生成文件中需要重命名的部分。
- [render] - 遍历所有文件，如果是一个模板文件（文本文件并且包含模板标记）就使用模板引擎渲染。
- [emit] - 将所有文件写入到目标目录。
- [install] - 自动执行 npm | yarn | pnpm 相关命令，安装项目的依赖。
- [init] - 自动执行 git init && git add && git commit 命令，初始化 Git 仓库。
- [complete] - 调用模板配置中的 complete 钩子函数。


---

[confirm]: https://github.com/zce/caz/tree/master/src/init/confirm.ts
[resolve]: https://github.com/zce/caz/tree/master/src/init/resolve.ts
[load]: https://github.com/zce/caz/tree/master/src/init/load.ts
[inquire]: https://github.com/zce/caz/tree/master/src/init/inquire.ts
[setup]: https://github.com/zce/caz/tree/master/src/init/setup.ts
[prepare]: https://github.com/zce/caz/tree/master/src/init/prepare.ts
[rename]: https://github.com/zce/caz/tree/master/src/init/rename.ts
[render]: https://github.com/zce/caz/tree/master/src/init/render.ts
[emit]: https://github.com/zce/caz/tree/master/src/init/emit.ts
[install]: https://github.com/zce/caz/tree/master/src/init/install.ts
[init]: https://github.com/zce/caz/tree/master/src/init/init.ts
[complete]: https://github.com/zce/caz/tree/master/src/init/complete.ts