# Writing Custom Scaffolding tools from Scratch

In reading this section, you'll learn how to create and distribute your own Scaffolding tools based on CAZ.

TODO: tutorial...

Now, please refer to the https://github.com/zce/create-nm
