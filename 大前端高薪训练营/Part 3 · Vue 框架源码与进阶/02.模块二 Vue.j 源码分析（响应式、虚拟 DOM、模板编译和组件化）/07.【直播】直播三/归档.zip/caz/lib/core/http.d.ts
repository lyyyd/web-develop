import fetch from 'node-fetch';
/**
 * Send a http request.
 * @param url url
 * @param init init
 */
export declare const request: (url: fetch.RequestInfo, init?: fetch.RequestInit | undefined) => Promise<fetch.Response>;
/**
 * Download remote resource to temporary file.
 * @param url remote url
 * @returns temporary filename
 */
export declare const download: (url: string) => Promise<string>;
