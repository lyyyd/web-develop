import { Context } from './types';
declare const _default: (ctx: Context) => Promise<void>;
/**
 * Render file if template.
 */
export default _default;
