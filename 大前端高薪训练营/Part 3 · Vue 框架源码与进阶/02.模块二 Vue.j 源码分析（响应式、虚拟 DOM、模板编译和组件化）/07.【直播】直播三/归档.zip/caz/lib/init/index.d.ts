import { Options, Context, Template } from './types';
declare const _default: (template: string, project?: string, options?: Options) => Promise<void>;
export default _default;
export { Options, Context, Template };
