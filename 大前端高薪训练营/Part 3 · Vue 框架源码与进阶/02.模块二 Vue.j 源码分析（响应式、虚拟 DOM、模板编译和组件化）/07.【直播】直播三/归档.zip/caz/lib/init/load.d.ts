import { Context } from './types';
declare const _default: (ctx: Context) => Promise<void>;
/**
 * Load template config.
 * @todo Adapt to any repository?
 */
export default _default;
