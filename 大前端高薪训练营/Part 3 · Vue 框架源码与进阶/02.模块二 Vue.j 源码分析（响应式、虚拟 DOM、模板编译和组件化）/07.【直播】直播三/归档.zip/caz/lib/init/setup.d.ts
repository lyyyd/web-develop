import { Context } from './types';
declare const _default: (ctx: Context) => Promise<void>;
/**
 * Apply template setup hook.
 */
export default _default;
