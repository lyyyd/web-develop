import { Context } from './types';
declare const _default: (ctx: Context) => Promise<void>;
/**
 * Prepare all template files.
 */
export default _default;
