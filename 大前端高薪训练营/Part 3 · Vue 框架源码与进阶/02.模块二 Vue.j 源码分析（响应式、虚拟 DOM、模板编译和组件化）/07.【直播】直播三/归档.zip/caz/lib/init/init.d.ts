import { Context } from './types';
declare const _default: (ctx: Context) => Promise<void>;
/**
 * Execute `git init && git add && git commit` command.
 */
export default _default;
