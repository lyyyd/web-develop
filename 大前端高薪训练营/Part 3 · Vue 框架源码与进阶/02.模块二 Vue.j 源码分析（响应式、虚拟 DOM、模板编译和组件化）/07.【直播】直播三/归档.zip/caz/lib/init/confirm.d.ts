import { Context } from './types';
declare const _default: (ctx: Context) => Promise<void>;
/**
 * Confirm destination.
 */
export default _default;
