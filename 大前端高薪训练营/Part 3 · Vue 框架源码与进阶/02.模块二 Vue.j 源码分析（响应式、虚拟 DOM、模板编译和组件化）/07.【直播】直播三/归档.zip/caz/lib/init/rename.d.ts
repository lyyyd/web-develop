import { Context } from './types';
declare const _default: (ctx: Context) => Promise<void>;
/**
 * Rename file if necessary.
 */
export default _default;
