import { Context } from './types';
declare const _default: (ctx: Context) => Promise<void>;
/**
 * Execute `npm | yarn | pnpm install` command.
 */
export default _default;
