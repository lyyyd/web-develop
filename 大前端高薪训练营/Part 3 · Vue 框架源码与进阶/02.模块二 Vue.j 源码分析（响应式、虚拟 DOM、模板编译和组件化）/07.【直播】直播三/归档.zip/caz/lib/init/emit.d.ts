import { Context } from './types';
declare const _default: (ctx: Context) => Promise<void>;
/**
 * Emit files to destination.
 */
export default _default;
