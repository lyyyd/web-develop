export interface ListOptions {
    json?: boolean;
    short?: boolean;
}
declare const _default: (owner?: string, options?: ListOptions) => Promise<void>;
/**
 * Show all available templates.
 */
export default _default;
