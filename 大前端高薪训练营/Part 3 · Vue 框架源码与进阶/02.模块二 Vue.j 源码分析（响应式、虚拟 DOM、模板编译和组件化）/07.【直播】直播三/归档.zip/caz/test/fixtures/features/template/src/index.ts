export default {
  name: '<%= name %>',
  version: '<%= version %>',
  description: '<%= description %>'
}
