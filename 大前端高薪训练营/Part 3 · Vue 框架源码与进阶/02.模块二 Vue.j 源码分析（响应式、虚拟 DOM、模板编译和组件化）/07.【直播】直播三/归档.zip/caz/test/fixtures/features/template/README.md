# <%= name %>

Name: <%= upper(name) %>
Version: <%= version %>
Description: <%= lower(description) %>
