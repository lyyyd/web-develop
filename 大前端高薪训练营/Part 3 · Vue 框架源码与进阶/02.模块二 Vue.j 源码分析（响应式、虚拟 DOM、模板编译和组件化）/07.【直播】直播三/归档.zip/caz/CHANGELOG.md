# Changelog

## [0.1.3] - 2020-08-16

- feat: using self built api instead github api

## [0.1.2] - 2020-08-14

- feat: setup after inquire
- fix: extract zip strip

## [0.1.1] - 2020-08-09

- fix: skip binary files when rendering templates (#5)
- chore: update dependency ora to v5.0.0

## [0.1.0] - 2020-08-02

- chore: initial release

## [0.0.0] - 2020-07-14

- feat: initial commit

<!-- http://keepachangelog.com/ -->

[0.1.3]: https://github.com/zce/caz/compare/v0.1.3...v0.1.3
[0.1.2]: https://github.com/zce/caz/compare/v0.1.1...v0.1.2
[0.1.1]: https://github.com/zce/caz/compare/v0.1.0...v0.1.1
[0.1.0]: https://github.com/zce/caz/compare/v0.0.0-alpha.2...v0.1.0
[0.0.0]: https://github.com/zce/caz/releases/tag/v0.0.0-alpha.2
