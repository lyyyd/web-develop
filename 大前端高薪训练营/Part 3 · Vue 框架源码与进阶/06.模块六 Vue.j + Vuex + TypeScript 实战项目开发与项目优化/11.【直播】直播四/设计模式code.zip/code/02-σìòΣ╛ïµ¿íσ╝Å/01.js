/**
 * 单例模式：只能创建一个实例，多次调用也只有1个实例
 */
class Singleton {
  constructor (name) {
    this.instance = null // 保存当前类的实例
    this.name = name
  }

  getName () {
    console.log(this.name)
  }

  static getInstance () {
    if (!this.instance) {
      this.instance = new Singleton()
    }
    return this.instance
  }
}

const s1 = Singleton.getInstance()
const s2 = Singleton.getInstance()

console.log(s1 === s2)

// const s1 = new Singleton()
// const s2 = new Singleton()
// const s3 = new Singleton()
