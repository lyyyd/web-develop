class LoginFrom {
  constructor () {}
  show () {}
  hide () {}
}

const createGetSingle = function (fn) {
  let instance
  return function () {
    if (!instance) {
      instance = new fn()
    }
    return instance
  }
}

const createLoginForm = createGetSingle(LoginFrom)

const form1 = createLoginForm()
const form2 = createLoginForm()

console.log(form1 === form2)

class A {}
const createA = createGetSingle(A)
const a1 = createA()
const a2 = createA()
console.log(a1 === a2)
