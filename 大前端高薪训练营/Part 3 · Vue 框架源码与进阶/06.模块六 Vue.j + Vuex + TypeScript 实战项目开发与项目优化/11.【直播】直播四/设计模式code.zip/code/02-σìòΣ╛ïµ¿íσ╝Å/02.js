class Singleton {
  constructor (name) {
    // this.instance = null // 保存当前类的实例
    this.name = name
  }

  getName () {
    console.log(this.name)
  }

  static getInstance = (function () {
    let instance = null
    return function () {
      if (!instance) {
        instance = new Singleton()
      }
      return instance
    }
  })()
}

const s1 = Singleton.getInstance()
const s2 = Singleton.getInstance()

console.log(s1 === s2)
