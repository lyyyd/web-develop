const calculateS = function (salry) {
  return salry * 4
}

const calculateA = function (salry) {
  return salry * 3
}

const calculateB = function (salry) {
  return salry * 2
}

const calculateBonus = function (level, salary) {
  if (level === 'S') {
    return calculateS(salary)
  } else if (level === 'A') {
    return calculateA(salary)
  } else if (level === 'B') {
    return calculateB(salary)
  }
}

calculateBonus('S', 1000)
