console.log(123)

/**
 * 策略模式
 * 发工资：
 *  S 4倍工资
 *  A 3倍
 *  B 2倍
 * 
 * 反模式
 */
const calculateBonus = function (level, salary) {
  if (level === 'S') {
    return salary * 4
  } else if (level === 'A') {
    return salary * 3
  } else if (level === 'B') {
    return salary * 2
  }
}

calculateBonus('S', 1000)
calculateBonus('B', 2000)


// 做游戏开发的、大量的面向对象：Canvas
