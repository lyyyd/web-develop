class CalculateS {
  calculate (salary) {
    return salary * 4
  }
}

class CalculateA {
  calculate (salary) {
    return salary * 3
  }
}

class CalculateB {
  calculate (salary) {
    return salary * 2
  }
}

class Bonus {
  constructor (salary, calculator) {
    this.salary = null
    this.calculator = null // 策略对象，具体的执行对象
  }

  setSalary (salary) {
    this.salary = salary
  }

  setCaculator (calculator) {
    this.calculator = calculator
  }

  getBonus () {
    return this.calculator.calculate(this.salary)
  }
}

const bonus = new Bonus()

bonus.setSalary(1000)

// 策略模式是在外部创建实例对象，工厂是内部，固定的
bonus.setCaculator(new calculateA()) // 设置策略对象

console.log(bonus.getBonus())
