new Vue({
  el: '#app',
  data: {
    num1: 0,
    num2: 0,
    result: 0,
    oprate: '+'
  },
  methods: {
    handleSubmit () {
      console.log(123)
    }
  }
})
