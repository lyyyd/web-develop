// 使用 Node.js 起一个 HTTP 服务

// 注意：测试 HTTTP 协议，最好使用原生的 http 模块来创建 HTTP 服务
//      不建议使用 Express、Koa、egg 等开发框架
const http = require('http')
const fs = require('fs')
const url = require('url')

const server = http.createServer()

// 任何请求进来，就会触发 request 请求事件，执行处理函数
server.on('request', (req, res) => {
  // 打印请求日志
  console.log(`${req.method} ${req.url}`)

  // 如果请求 /，则返回 index.html
  // 如果请求 /a.js，则返回 a.js

  const { pathname: path } = url.parse(req.url)

  // 首页
  if (path === '/') {
    // 每次请求进来都要重新读取该文件
    const data = fs.readFileSync('./index.html')
    res.end(data)
  } else if (path === '/a.js') {
    const data = fs.readFileSync('./a.js')

    // res.setHeader('响应头名称', '响应头值')
    // res.setHeader('响应头名称', '响应头值')

    // res.writeHead('响应码', {
    //   '响应头名': '响应头值',
    //   '响应头名': '响应头值',
    //   '响应头名': '响应头值'
    // })

    // res.setHeader('foo', 'bar')
    // res.setHeader('Cache-Control', 'no-store')

    // 测试的时候一定要注册：关闭禁用缓存
    res.setHeader('Cache-Control', 'max-age=20')

    res.end(data)
  } else {
    // 不在受理范围之内的，统一 404
    res.statusCode = 404
    res.end()
  }

  // res.write('Hello')
  // res.write('World!')
  // res.end()

  // res.end('Hello World!')

//   res.end(`
//   <!DOCTYPE html>
// <html lang="en">
// <head>
//   <meta charset="UTF-8">
//   <meta name="viewport" content="width=device-width, initial-scale=1.0">
//   <title>Document</title>
// </head>
// <body>
//   <h1>关于 HTTP 缓存</h1>
// </body>
// </html>
//   `)
})

server.listen(3000, () => {
  console.log('running http://localhost:3000/')
})
