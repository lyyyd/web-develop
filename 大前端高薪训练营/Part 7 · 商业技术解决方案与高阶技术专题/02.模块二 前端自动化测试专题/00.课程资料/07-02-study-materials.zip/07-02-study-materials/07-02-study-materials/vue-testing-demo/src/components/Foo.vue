<template>
  <h1>Foo 组件</h1>
</template>
