<template>
  <div id="app">
    <!-- <TodoApp/> -->
    <router-view></router-view>
  </div>
</template>

<script>
// import TodoApp from '@/components/TodoApp'

export default {
  name: 'App',
  components: {
    // TodoApp
  }
}
</script>
