# devtools-samples

This repository contains samples for demonstrating Chrome DevTools features. These
samples are used in the [official DevTools docs][official] as well as the
[What's New In DevTools][WNDT] videos.

[official]: https://developers.google.com/web/tools/chrome-devtools
[WNDT]: https://www.youtube.com/playlist?list=PLNYkxOF6rcIBDSojZWBv4QJNoT4GNYzQD

## Disclaimer

This is not an official Google product.
