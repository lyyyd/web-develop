/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\component\\component.hml?entry");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./lib/json.js!./lib/style.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\components\\bottomNav\\index.css":
/*!**************************************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/style.js!D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/common/components/bottomNav/index.css ***!
  \**************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {}

/***/ }),

/***/ "./lib/json.js!./lib/style.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\component\\component.css":
/*!******************************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/style.js!D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/pages/component/component.css ***!
  \******************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  ".container": {
    "flexDirection": "column",
    "justifyContent": "flex-start",
    "alignItems": "center"
  },
  ".tabs": {
    "width": "100%"
  },
  ".tabcontent": {
    "width": "100%",
    "height": "80%",
    "marginTop": "0px",
    "marginRight": "10px",
    "marginBottom": "0px",
    "marginLeft": "10px"
  },
  ".item-content": {
    "height": "100%",
    "display": "flex",
    "flexDirection": "column",
    "justifyContent": "flex-start",
    "borderTopWidth": "2px",
    "borderRightWidth": "2px",
    "borderBottomWidth": "2px",
    "borderLeftWidth": "2px",
    "borderTopStyle": "solid",
    "borderRightStyle": "solid",
    "borderBottomStyle": "solid",
    "borderLeftStyle": "solid",
    "borderTopColor": "#0000ff",
    "borderRightColor": "#0000ff",
    "borderBottomColor": "#0000ff",
    "borderLeftColor": "#0000ff",
    "width": "100%",
    "paddingTop": "10px",
    "paddingRight": "10px",
    "paddingBottom": "10px",
    "paddingLeft": "10px"
  },
  ".item-title": {
    "fontSize": "60px"
  },
  ".tab-bar": {
    "marginTop": "0px",
    "marginRight": "0px",
    "marginBottom": "0px",
    "marginLeft": "0px",
    "height": "50px"
  },
  ".tab-text": {
    "width": "100%",
    "textAlign": "center",
    "fontSize": "20px"
  },
  "button": {
    "marginBottom": "10px"
  }
}

/***/ }),

/***/ "./lib/json.js!./lib/template.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\components\\bottomNav\\index.hml":
/*!*****************************************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/template.js!D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/common/components/bottomNav/index.hml ***!
  \*****************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  "attr": {
    "debugLine": "common/components/bottomNav/index:1"
  },
  "type": "toolbar",
  "style": {
    "position": "fixed",
    "bottom": "0px"
  },
  "children": [
    {
      "attr": {
        "debugLine": "common/components/bottomNav/index:2",
        "tid": "id",
        "icon": function () {return this.$item.icon},
        "value": function () {return this.$item.name}
      },
      "type": "toolbar-item",
      "repeat": function () {return this.menu},
      "events": {
        "click": function (evt) {this.changeNav(this.$idx,evt)}
      }
    }
  ]
}

/***/ }),

/***/ "./lib/json.js!./lib/template.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\component\\component.hml":
/*!*********************************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/template.js!D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/pages/component/component.hml ***!
  \*********************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  "attr": {
    "debugLine": "pages/component/component:4",
    "className": "container"
  },
  "type": "div",
  "classList": [
    "container"
  ],
  "children": [
    {
      "attr": {
        "debugLine": "pages/component/component:5",
        "className": "tabs",
        "index": "0",
        "vertical": "false"
      },
      "type": "tabs",
      "classList": [
        "tabs"
      ],
      "events": {
        "change": "change"
      },
      "children": [
        {
          "attr": {
            "debugLine": "pages/component/component:6",
            "className": "tab-bar",
            "mode": "fixed"
          },
          "type": "tab-bar",
          "classList": [
            "tab-bar"
          ],
          "children": [
            {
              "attr": {
                "debugLine": "pages/component/component:7",
                "className": "tab-text",
                "value": "容器组件"
              },
              "type": "text",
              "classList": [
                "tab-text"
              ]
            },
            {
              "attr": {
                "debugLine": "pages/component/component:8",
                "className": "tab-text",
                "value": "基础组件"
              },
              "type": "text",
              "classList": [
                "tab-text"
              ]
            },
            {
              "attr": {
                "debugLine": "pages/component/component:9",
                "className": "tab-text",
                "value": "其他"
              },
              "type": "text",
              "classList": [
                "tab-text"
              ]
            }
          ]
        },
        {
          "attr": {
            "debugLine": "pages/component/component:11",
            "className": "tabcontent",
            "scrollable": "true"
          },
          "type": "tab-content",
          "classList": [
            "tabcontent"
          ],
          "children": [
            {
              "attr": {
                "debugLine": "pages/component/component:12",
                "className": "item-content"
              },
              "type": "div",
              "classList": [
                "item-content"
              ],
              "children": [
                {
                  "attr": {
                    "debugLine": "pages/component/component:13",
                    "data": "0",
                    "type": "capsule",
                    "value": "div"
                  },
                  "type": "button",
                  "events": {
                    "click": "goComp"
                  }
                },
                {
                  "attr": {
                    "debugLine": "pages/component/component:16",
                    "data": "1",
                    "type": "capsule",
                    "value": "dialog"
                  },
                  "type": "button",
                  "events": {
                    "click": "goComp"
                  }
                },
                {
                  "attr": {
                    "debugLine": "pages/component/component:19",
                    "data": "2",
                    "type": "capsule",
                    "value": "list"
                  },
                  "type": "button",
                  "events": {
                    "click": "goComp"
                  }
                },
                {
                  "attr": {
                    "debugLine": "pages/component/component:22",
                    "data": "3",
                    "type": "capsule",
                    "value": "swiper"
                  },
                  "type": "button",
                  "events": {
                    "click": "goComp"
                  }
                }
              ]
            },
            {
              "attr": {
                "debugLine": "pages/component/component:26",
                "className": "item-content"
              },
              "type": "div",
              "classList": [
                "item-content"
              ],
              "children": [
                {
                  "attr": {
                    "debugLine": "pages/component/component:27",
                    "data": "4",
                    "type": "capsule",
                    "value": "toolbar"
                  },
                  "type": "button",
                  "events": {
                    "click": "goComp"
                  }
                },
                {
                  "attr": {
                    "debugLine": "pages/component/component:30",
                    "data": "5",
                    "type": "capsule",
                    "value": "chart"
                  },
                  "type": "button",
                  "events": {
                    "click": "goComp"
                  }
                },
                {
                  "attr": {
                    "debugLine": "pages/component/component:33",
                    "data": "6",
                    "type": "capsule",
                    "value": "picker"
                  },
                  "type": "button",
                  "events": {
                    "click": "goComp"
                  }
                },
                {
                  "attr": {
                    "debugLine": "pages/component/component:36",
                    "data": "7",
                    "type": "capsule",
                    "value": "input"
                  },
                  "type": "button",
                  "events": {
                    "click": "goComp"
                  }
                }
              ]
            },
            {
              "attr": {
                "debugLine": "pages/component/component:40",
                "className": "item-content"
              },
              "type": "div",
              "classList": [
                "item-content"
              ],
              "children": [
                {
                  "attr": {
                    "debugLine": "pages/component/component:41",
                    "className": "item-title",
                    "value": "Third screen"
                  },
                  "type": "text",
                  "classList": [
                    "item-title"
                  ]
                }
              ]
            }
          ]
        }
      ]
    },
    {
      "attr": {
        "debugLine": "pages/component/component:45",
        "type": "capsule",
        "value": "回退"
      },
      "type": "button",
      "events": {
        "click": "goBack"
      }
    },
    {
      "attr": {
        "debugLine": "pages/component/component:49",
        "curIndex": "2"
      },
      "type": "bottomnav"
    }
  ]
}

/***/ }),

/***/ "./lib/loader.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\components\\bottomNav\\index.hml?name=bottomnav":
/*!****************************************************************************************************************************************!*\
  !*** ./lib/loader.js!D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/common/components/bottomNav/index.hml?name=bottomnav ***!
  \****************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $app_template$ = __webpack_require__(/*! !./lib/json.js!./lib/template.js!./index.hml */ "./lib/json.js!./lib/template.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\components\\bottomNav\\index.hml")
var $app_style$ = __webpack_require__(/*! !./lib/json.js!./lib/style.js!./index.css */ "./lib/json.js!./lib/style.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\components\\bottomNav\\index.css")
var $app_script$ = __webpack_require__(/*! !./lib/script.js!./node_modules/babel-loader?presets[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!./index.js */ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\components\\bottomNav\\index.js")

$app_define$('@app-component/bottomnav', [], function($app_require$, $app_exports$, $app_module$) {

$app_script$($app_module$, $app_exports$, $app_require$)
if ($app_exports$.__esModule && $app_exports$.default) {
$app_module$.exports = $app_exports$.default
}

$app_module$.exports.template = $app_template$

$app_module$.exports.style = $app_style$

})


/***/ }),

/***/ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\components\\bottomNav\\index.js":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./lib/script.js!./node_modules/babel-loader/lib?presets[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/common/components/bottomNav/index.js ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = function(module, exports, $app_require$){"use strict";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _system = _interopRequireDefault($app_require$("@app-module/system.router"));

var _default = {
  props: ['curIndex'],
  data: {
    menu: [{
      icon: 'common/icons/home.png',
      active_icon: 'common/icons/home_active.png',
      name: '首页',
      path: 'pages/index/index',
      active: true
    }, {
      icon: 'common/icons/comment.png',
      active_icon: 'common/icons/comment_active.png',
      name: '新闻',
      path: 'pages/news/news',
      active: false
    }, {
      icon: 'common/icons/cart.png',
      active_icon: 'common/icons/cart_active.png',
      name: '组件',
      path: 'pages/component/component',
      active: false
    }, {
      icon: 'common/icons/user.png',
      active_icon: 'common/icons/user_active.png',
      name: '我',
      path: 'pages/profile/index',
      active: false
    }]
  },
  onInit: function onInit() {
    this.menu[this.curIndex].icon = this.menu[this.curIndex].active_icon;
  },
  changeNav: function changeNav(id) {
    console.log('current id: ' + id);

    _system["default"].replace({
      uri: this.menu[id].path
    });
  }
};
exports["default"] = _default;
var moduleOwn = exports.default || module.exports;
var accessors = ['public', 'protected', 'private'];
if (moduleOwn.data && accessors.some(function (acc) {
    return moduleOwn[acc];
  })) {
  throw new Error('For VM objects, attribute data must not coexist with public, protected, or private. Please replace data with public.');
} else if (!moduleOwn.data) {
  moduleOwn.data = {};
  moduleOwn._descriptor = {};
  accessors.forEach(function(acc) {
    var accType = typeof moduleOwn[acc];
    if (accType === 'object') {
      moduleOwn.data = Object.assign(moduleOwn.data, moduleOwn[acc]);
      for (var name in moduleOwn[acc]) {
        moduleOwn._descriptor[name] = {access : acc};
      }
    } else if (accType === 'function') {
      console.warn('For VM objects, attribute ' + acc + ' value must not be a function. Change the value to an object.');
    }
  });
}}
/* generated by ace-loader */


/***/ }),

/***/ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\component\\component.js":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./lib/script.js!./node_modules/babel-loader/lib?presets[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/pages/component/component.js ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = function(module, exports, $app_require$){"use strict";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _system = _interopRequireDefault($app_require$("@app-module/system.router"));

var _default = {
  data: {
    title: 'World',
    uris: ['pages/component/container/div/index', 'pages/component/container/dialog/index', 'pages/component/container/list/index', 'pages/component/container/swiper/index', 'pages/component/basic/toolbar/index', 'pages/component/basic/chart/index', 'pages/component/basic/picker/index', 'pages/component/basic/input/index']
  },
  goBack: function goBack() {
    _system["default"].back();
  },
  change: function change(e) {
    console.log("Tab index: " + e.index);
  },
  goComp: function goComp(e) {
    var data = e.target.attr.data;

    _system["default"].push({
      uri: this.uris[data]
    });
  }
};
exports["default"] = _default;
var moduleOwn = exports.default || module.exports;
var accessors = ['public', 'protected', 'private'];
if (moduleOwn.data && accessors.some(function (acc) {
    return moduleOwn[acc];
  })) {
  throw new Error('For VM objects, attribute data must not coexist with public, protected, or private. Please replace data with public.');
} else if (!moduleOwn.data) {
  moduleOwn.data = {};
  moduleOwn._descriptor = {};
  accessors.forEach(function(acc) {
    var accType = typeof moduleOwn[acc];
    if (accType === 'object') {
      moduleOwn.data = Object.assign(moduleOwn.data, moduleOwn[acc]);
      for (var name in moduleOwn[acc]) {
        moduleOwn._descriptor[name] = {access : acc};
      }
    } else if (accType === 'function') {
      console.warn('For VM objects, attribute ' + acc + ' value must not be a function. Change the value to an object.');
    }
  });
}}
/* generated by ace-loader */


/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\component\\component.hml?entry":
/*!*******************************************************************************************************!*\
  !*** D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/pages/component/component.hml?entry ***!
  \*******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(/*! !./lib/loader.js!../../common/components/bottomNav/index.hml?name=bottomnav */ "./lib/loader.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\components\\bottomNav\\index.hml?name=bottomnav")
var $app_template$ = __webpack_require__(/*! !./lib/json.js!./lib/template.js!./component.hml */ "./lib/json.js!./lib/template.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\component\\component.hml")
var $app_style$ = __webpack_require__(/*! !./lib/json.js!./lib/style.js!./component.css */ "./lib/json.js!./lib/style.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\component\\component.css")
var $app_script$ = __webpack_require__(/*! !./lib/script.js!./node_modules/babel-loader?presets[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!./component.js */ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\component\\component.js")

$app_define$('@app-component/component', [], function($app_require$, $app_exports$, $app_module$) {

$app_script$($app_module$, $app_exports$, $app_require$)
if ($app_exports$.__esModule && $app_exports$.default) {
$app_module$.exports = $app_exports$.default
}

$app_module$.exports.template = $app_template$

$app_module$.exports.style = $app_style$

})
$app_bootstrap$('@app-component/component',undefined,undefined)

/***/ })

/******/ });