/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\index\\index.hml?entry");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./lib/json.js!./lib/style.js!./node_modules/less-loader/dist/cjs.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\index\\index.less":
/*!**************************************************************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/style.js!./node_modules/less-loader/dist/cjs.js!D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/pages/index/index.less ***!
  \**************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  ".container": {
    "flexDirection": "column",
    "justifyContent": "flex-start",
    "alignItems": "center",
    "backgroundColor": "#ffffbb"
  },
  ".title": {
    "fontSize": "40px",
    "color": "#000000",
    "opacity": 0.9
  },
  ".tag-list": {
    "width": "100%",
    "height": "300px"
  },
  ".weather-item": {
    "width": "100%",
    "display": "flex",
    "flexDirection": "column",
    "justifyContent": "space-between",
    "marginTop": "0px",
    "marginRight": "10px",
    "marginBottom": "0px",
    "marginLeft": "10px"
  },
  ".item-header": {
    "backgroundColor": "#ddffbb",
    "width": "100%",
    "height": "40px",
    "justifyContent": "space-between"
  },
  ".item-header text": {
    "fontSize": "18px",
    "marginTop": "5px",
    "marginRight": "10px",
    "marginBottom": "5px",
    "marginLeft": "10px"
  },
  ".item-body text": {
    "fontSize": "18px",
    "marginTop": "5px",
    "marginRight": "10px",
    "marginBottom": "5px",
    "marginLeft": "10px"
  },
  ".item-body": {
    "width": "100%",
    "borderTopWidth": "1px",
    "borderRightWidth": "1px",
    "borderBottomWidth": "1px",
    "borderLeftWidth": "1px",
    "borderTopStyle": "solid",
    "borderRightStyle": "solid",
    "borderBottomStyle": "solid",
    "borderLeftStyle": "solid",
    "borderTopColor": "#ddffbb",
    "borderRightColor": "#ddffbb",
    "borderBottomColor": "#ddffbb",
    "borderLeftColor": "#ddffbb",
    "display": "flex",
    "flexDirection": "row",
    "alignItems": "center"
  },
  ".weather-icon": {
    "width": "50px",
    "height": "50px"
  },
  "@MEDIA": [
    {
      "condition": "screen and (device-type: tablet) and (orientation: landscape)",
      ".title": {
        "fontSize": "100px"
      }
    },
    {
      "condition": "screen and (device-type: wearable)",
      ".title": {
        "fontSize": "28px",
        "color": "#FFFFFF"
      }
    },
    {
      "condition": "screen and (device-type: tv)",
      ".container": {
        "backgroundImage": "../../common/images/Wallpaper.png",
        "backgroundSize": "cover",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center"
      },
      ".title": {
        "fontSize": "100px",
        "color": "#FFFFFF"
      }
    },
    {
      "condition": "screen and (device-type: phone) and (orientation: landscape)",
      ".title": {
        "fontSize": "60px"
      }
    }
  ]
}

/***/ }),

/***/ "./lib/json.js!./lib/style.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\components\\bottomNav\\index.css":
/*!**************************************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/style.js!D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/common/components/bottomNav/index.css ***!
  \**************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {}

/***/ }),

/***/ "./lib/json.js!./lib/template.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\components\\bottomNav\\index.hml":
/*!*****************************************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/template.js!D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/common/components/bottomNav/index.hml ***!
  \*****************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  "attr": {
    "debugLine": "common/components/bottomNav/index:1"
  },
  "type": "toolbar",
  "style": {
    "position": "fixed",
    "bottom": "0px"
  },
  "children": [
    {
      "attr": {
        "debugLine": "common/components/bottomNav/index:2",
        "tid": "id",
        "icon": function () {return this.$item.icon},
        "value": function () {return this.$item.name}
      },
      "type": "toolbar-item",
      "repeat": function () {return this.menu},
      "events": {
        "click": function (evt) {this.changeNav(this.$idx,evt)}
      }
    }
  ]
}

/***/ }),

/***/ "./lib/json.js!./lib/template.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\index\\index.hml":
/*!*************************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/template.js!D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/pages/index/index.hml ***!
  \*************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  "attr": {
    "debugLine": "pages/index/index:3",
    "className": "container"
  },
  "type": "div",
  "classList": [
    "container"
  ],
  "children": [
    {
      "attr": {
        "debugLine": "pages/index/index:4",
        "className": "title",
        "value": function () {return (this.$t('strings.hello')) + ' : ' + (this.title) + ' ' + (this.$t('strings.settings'))}
      },
      "type": "text",
      "classList": [
        "title"
      ],
      "style": {
        "color": "#2129D9"
      }
    },
    {
      "attr": {
        "debugLine": "pages/index/index:8",
        "className": "image-player",
        "id": "animator",
        "images": function () {return this.images},
        "duration": "1s"
      },
      "type": "image-animator",
      "classList": [
        "image-player"
      ],
      "id": "animator",
      "events": {
        "click": "handleClick"
      }
    },
    {
      "attr": {
        "debugLine": "pages/index/index:15",
        "className": "tag-list"
      },
      "type": "list",
      "classList": [
        "tag-list"
      ],
      "children": [
        {
          "attr": {
            "debugLine": "pages/index/index:16",
            "className": "weather-item"
          },
          "type": "list-item",
          "repeat": function () {return this.threeDays},
          "classList": [
            "weather-item"
          ],
          "children": [
            {
              "attr": {
                "debugLine": "pages/index/index:17",
                "className": "item-header"
              },
              "type": "div",
              "classList": [
                "item-header"
              ],
              "children": [
                {
                  "attr": {
                    "debugLine": "pages/index/index:18",
                    "value": function () {return this.$item.fxDate}
                  },
                  "type": "text"
                },
                {
                  "attr": {
                    "debugLine": "pages/index/index:19",
                    "value": function () {return (this.$item.tempMin) + '° - ' + (this.$item.tempMax) + '°'}
                  },
                  "type": "text"
                }
              ]
            },
            {
              "attr": {
                "debugLine": "pages/index/index:21",
                "className": "item-body"
              },
              "type": "div",
              "classList": [
                "item-body"
              ],
              "children": [
                {
                  "attr": {
                    "debugLine": "pages/index/index:22",
                    "className": "weather-icon",
                    "src": function () {return '/common/weather/' + (this.$item.iconDay) + '.png'}
                  },
                  "type": "image",
                  "classList": [
                    "weather-icon"
                  ]
                },
                {
                  "attr": {
                    "debugLine": "pages/index/index:23"
                  },
                  "type": "div",
                  "children": [
                    {
                      "attr": {
                        "debugLine": "pages/index/index:24",
                        "value": function () {return this.$item.textDay}
                      },
                      "type": "text"
                    },
                    {
                      "attr": {
                        "debugLine": "pages/index/index:25",
                        "value": function () {return (this.$item.windDirDay) + ': ' + (this.$item.windScaleDay)}
                      },
                      "type": "text"
                    }
                  ]
                }
              ]
            }
          ]
        }
      ]
    },
    {
      "attr": {
        "debugLine": "pages/index/index:31",
        "type": "capsule",
        "value": "设置"
      },
      "type": "button",
      "events": {
        "click": "setValue"
      }
    },
    {
      "attr": {
        "debugLine": "pages/index/index:34",
        "type": "capsule",
        "value": "获取"
      },
      "type": "button",
      "events": {
        "click": "getValue"
      }
    },
    {
      "attr": {
        "debugLine": "pages/index/index:38",
        "curIndex": "0"
      },
      "type": "bottomnav"
    }
  ]
}

/***/ }),

/***/ "./lib/loader.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\components\\bottomNav\\index.hml?name=bottomnav":
/*!****************************************************************************************************************************************!*\
  !*** ./lib/loader.js!D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/common/components/bottomNav/index.hml?name=bottomnav ***!
  \****************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $app_template$ = __webpack_require__(/*! !./lib/json.js!./lib/template.js!./index.hml */ "./lib/json.js!./lib/template.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\components\\bottomNav\\index.hml")
var $app_style$ = __webpack_require__(/*! !./lib/json.js!./lib/style.js!./index.css */ "./lib/json.js!./lib/style.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\components\\bottomNav\\index.css")
var $app_script$ = __webpack_require__(/*! !./lib/script.js!./node_modules/babel-loader?presets[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!./index.js */ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\components\\bottomNav\\index.js")

$app_define$('@app-component/bottomnav', [], function($app_require$, $app_exports$, $app_module$) {

$app_script$($app_module$, $app_exports$, $app_require$)
if ($app_exports$.__esModule && $app_exports$.default) {
$app_module$.exports = $app_exports$.default
}

$app_module$.exports.template = $app_template$

$app_module$.exports.style = $app_style$

})


/***/ }),

/***/ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\components\\bottomNav\\index.js":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./lib/script.js!./node_modules/babel-loader/lib?presets[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/common/components/bottomNav/index.js ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = function(module, exports, $app_require$){"use strict";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _system = _interopRequireDefault($app_require$("@app-module/system.router"));

var _default = {
  props: ['curIndex'],
  data: {
    menu: [{
      icon: 'common/icons/home.png',
      active_icon: 'common/icons/home_active.png',
      name: '首页',
      path: 'pages/index/index',
      active: true
    }, {
      icon: 'common/icons/comment.png',
      active_icon: 'common/icons/comment_active.png',
      name: '新闻',
      path: 'pages/news/news',
      active: false
    }, {
      icon: 'common/icons/cart.png',
      active_icon: 'common/icons/cart_active.png',
      name: '组件',
      path: 'pages/component/component',
      active: false
    }, {
      icon: 'common/icons/user.png',
      active_icon: 'common/icons/user_active.png',
      name: '我',
      path: 'pages/profile/index',
      active: false
    }]
  },
  onInit: function onInit() {
    this.menu[this.curIndex].icon = this.menu[this.curIndex].active_icon;
  },
  changeNav: function changeNav(id) {
    console.log('current id: ' + id);

    _system["default"].replace({
      uri: this.menu[id].path
    });
  }
};
exports["default"] = _default;
var moduleOwn = exports.default || module.exports;
var accessors = ['public', 'protected', 'private'];
if (moduleOwn.data && accessors.some(function (acc) {
    return moduleOwn[acc];
  })) {
  throw new Error('For VM objects, attribute data must not coexist with public, protected, or private. Please replace data with public.');
} else if (!moduleOwn.data) {
  moduleOwn.data = {};
  moduleOwn._descriptor = {};
  accessors.forEach(function(acc) {
    var accType = typeof moduleOwn[acc];
    if (accType === 'object') {
      moduleOwn.data = Object.assign(moduleOwn.data, moduleOwn[acc]);
      for (var name in moduleOwn[acc]) {
        moduleOwn._descriptor[name] = {access : acc};
      }
    } else if (accType === 'function') {
      console.warn('For VM objects, attribute ' + acc + ' value must not be a function. Change the value to an object.');
    }
  });
}}
/* generated by ace-loader */


/***/ }),

/***/ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\index\\index.js":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./lib/script.js!./node_modules/babel-loader/lib?presets[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/pages/index/index.js ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = function(module, exports, $app_require$){"use strict";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _newArrowCheck2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/newArrowCheck */ "./node_modules/@babel/runtime/helpers/newArrowCheck.js"));

var _system = _interopRequireDefault($app_require$("@app-module/system.router"));

var _system2 = _interopRequireDefault(systemplugin.fetch);

var _qweather3ds = _interopRequireDefault(__webpack_require__(/*! ../../common/data/qweather3ds.js */ "D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\data\\qweather3ds.js"));

var _system3 = _interopRequireDefault(systemplugin.geolocation);

var _system4 = _interopRequireDefault(systemplugin.storage);

var _default = {
  data: {
    title: "123",
    images: [{
      src: '/common/images/bg-tv.jpg'
    }, {
      src: '/common/images/Wallpaper.png'
    }],
    mylocation: '117.33,39.55',
    threeDays: _qweather3ds["default"].daily
  },
  onInit: function onInit() {
    console.log('onInit');
    console.log(this.$app.$def.globalData.appVersion);
    this.$app.$def.globalHello();
    this.$delete('title');
    this.$set('title', 666);
    var that = this;

    _system3["default"].getLocation({
      success: function success(data) {
        console.log('location: ' + JSON.stringify(data));
        that.mylocation = data.longitude + ',' + data.latitude;
      },
      complete: function complete() {
        that.get3ds();
      }
    });
  },
  get3ds: function get3ds() {
    var _this = this;

    var that = this;
    var api = 'https://devapi.qweather.com/v7/weather/3d';
    console.log('mylocation: ' + this.mylocation);

    _system2["default"].fetch({
      url: api + '?location=' + this.mylocation + '&key=687e517f06684448a9f4695721414a07',
      method: 'GET',
      responseType: 'json',
      success: function success(res) {
        (0, _newArrowCheck2["default"])(this, _this);
        console.log('666666666: ' + JSON.stringify(res));

        if (res.code == 200) {
          var target = JSON.parse(res.data);
          that.threeDays = target.daily;
        } else {
          console.log('查询天气失败');
        }
      }.bind(this)
    });
  },
  handleClick: function handleClick() {
    var animator = this.$element('animator');
    var state = animator.getState();

    if (state === 'paused') {
      animator.resume();
    } else if (state === 'stopped') {
      animator.start();
    } else {
      animator.pause();
    }
  },
  onReady: function onReady() {
    console.log('onReady');
  },
  onShow: function onShow() {
    console.log('onShow');
  },
  onActive: function onActive() {
    console.log('onActive');
  },
  onInactive: function onInactive() {
    console.log('onInactive');
  },
  onHide: function onHide() {
    console.log('onHide');
  },
  onDestroy: function onDestroy() {
    console.log('onDestroy');
  },
  setValue: function setValue() {
    _system4["default"].set({
      key: 'hello',
      value: {
        username: 'zhangsan',
        age: 20
      },
      success: function success() {
        console.log('call storage.set success.');
      },
      fail: function fail(data, code) {
        console.log('call storage.set fail, code: ' + code + ', data: ' + data);
      }
    });
  },
  getValue: function getValue() {
    _system4["default"].get({
      key: 'hello',
      success: function success(data) {
        console.log('call storage.get success: ' + data);
      },
      fail: function fail(data, code) {
        console.log('call storage.get fail, code: ' + code + ', data: ' + data);
      },
      complete: function complete() {
        console.log('call complete');
      }
    });
  }
};
exports["default"] = _default;
var moduleOwn = exports.default || module.exports;
var accessors = ['public', 'protected', 'private'];
if (moduleOwn.data && accessors.some(function (acc) {
    return moduleOwn[acc];
  })) {
  throw new Error('For VM objects, attribute data must not coexist with public, protected, or private. Please replace data with public.');
} else if (!moduleOwn.data) {
  moduleOwn.data = {};
  moduleOwn._descriptor = {};
  accessors.forEach(function(acc) {
    var accType = typeof moduleOwn[acc];
    if (accType === 'object') {
      moduleOwn.data = Object.assign(moduleOwn.data, moduleOwn[acc]);
      for (var name in moduleOwn[acc]) {
        moduleOwn._descriptor[name] = {access : acc};
      }
    } else if (accType === 'function') {
      console.warn('For VM objects, attribute ' + acc + ' value must not be a function. Change the value to an object.');
    }
  });
}}
/* generated by ace-loader */


/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/newArrowCheck.js":
/*!**************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/newArrowCheck.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _newArrowCheck(innerThis, boundThis) {
  if (innerThis !== boundThis) {
    throw new TypeError("Cannot instantiate an arrow function");
  }
}

module.exports = _newArrowCheck;

/***/ }),

/***/ "D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\data\\qweather3ds.js":
/*!**********************************************************************************************!*\
  !*** D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/common/data/qweather3ds.js ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var _default = {
  "code": "200",
  "updateTime": "2021-07-01T10:35+08:00",
  "fxLink": "http://hfx.link/1tjo1",
  "daily": [{
    "fxDate": "2021-07-01",
    "sunrise": "04:49",
    "sunset": "19:47",
    "moonrise": "00:00",
    "moonset": "11:35",
    "moonPhase": "亏凸月",
    "tempMax": "30",
    "tempMin": "22",
    "iconDay": "302",
    "textDay": "雷阵雨",
    "iconNight": "305",
    "textNight": "小雨",
    "wind360Day": "180",
    "windDirDay": "南风",
    "windScaleDay": "1-2",
    "windSpeedDay": "3",
    "wind360Night": "45",
    "windDirNight": "东北风",
    "windScaleNight": "1-2",
    "windSpeedNight": "3",
    "humidity": "61",
    "precip": "2.5",
    "pressure": "999",
    "vis": "24",
    "cloud": "60",
    "uvIndex": "4"
  }, {
    "fxDate": "2021-07-02",
    "sunrise": "04:49",
    "sunset": "19:47",
    "moonrise": "00:15",
    "moonset": "12:35",
    "moonPhase": "下弦月",
    "tempMax": "28",
    "tempMin": "21",
    "iconDay": "302",
    "textDay": "雷阵雨",
    "iconNight": "302",
    "textNight": "雷阵雨",
    "wind360Day": "0",
    "windDirDay": "北风",
    "windScaleDay": "1-2",
    "windSpeedDay": "3",
    "wind360Night": "45",
    "windDirNight": "东北风",
    "windScaleNight": "1-2",
    "windSpeedNight": "3",
    "humidity": "96",
    "precip": "7.6",
    "pressure": "995",
    "vis": "3",
    "cloud": "54",
    "uvIndex": "3"
  }, {
    "fxDate": "2021-07-03",
    "sunrise": "04:50",
    "sunset": "19:47",
    "moonrise": "00:37",
    "moonset": "13:35",
    "moonPhase": "残月",
    "tempMax": "27",
    "tempMin": "21",
    "iconDay": "104",
    "textDay": "阴",
    "iconNight": "154",
    "textNight": "阴",
    "wind360Day": "90",
    "windDirDay": "东风",
    "windScaleDay": "1-2",
    "windSpeedDay": "3",
    "wind360Night": "90",
    "windDirNight": "东风",
    "windScaleNight": "1-2",
    "windSpeedNight": "3",
    "humidity": "84",
    "precip": "0.0",
    "pressure": "997",
    "vis": "24",
    "cloud": "25",
    "uvIndex": "11"
  }],
  "refer": {
    "sources": ["Weather China"],
    "license": ["no commercial use"]
  }
};
exports["default"] = _default;

/***/ }),

/***/ "D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\index\\index.hml?entry":
/*!***********************************************************************************************!*\
  !*** D:/lagou/hongmeng/code/helloempty/entry/src/main/js/default/pages/index/index.hml?entry ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(/*! !./lib/loader.js!../../common/components/bottomNav/index.hml?name=bottomnav */ "./lib/loader.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\common\\components\\bottomNav\\index.hml?name=bottomnav")
var $app_template$ = __webpack_require__(/*! !./lib/json.js!./lib/template.js!./index.hml */ "./lib/json.js!./lib/template.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\index\\index.hml")
var $app_style$ = __webpack_require__(/*! !./lib/json.js!./lib/style.js!./node_modules/less-loader!./index.less */ "./lib/json.js!./lib/style.js!./node_modules/less-loader/dist/cjs.js!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\index\\index.less")
var $app_script$ = __webpack_require__(/*! !./lib/script.js!./node_modules/babel-loader?presets[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=C:/Users/lct/AppData/Local/Huawei/Sdk/js/2.1.1.21/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!./index.js */ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=C:\\Users\\lct\\AppData\\Local\\Huawei\\Sdk\\js\\2.1.1.21\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!D:\\lagou\\hongmeng\\code\\helloempty\\entry\\src\\main\\js\\default\\pages\\index\\index.js")

$app_define$('@app-component/index', [], function($app_require$, $app_exports$, $app_module$) {

$app_script$($app_module$, $app_exports$, $app_require$)
if ($app_exports$.__esModule && $app_exports$.default) {
$app_module$.exports = $app_exports$.default
}

$app_module$.exports.template = $app_template$

$app_module$.exports.style = $app_style$

})
$app_bootstrap$('@app-component/index',undefined,undefined)

/***/ })

/******/ });