export default {
    onCreate() {
        console.info('TestApplication onCreate');
    },
    onDestroy() {
        console.info('TestApplication onDestroy');
    }
};
