import '../css/main.css'

console.log(1111)