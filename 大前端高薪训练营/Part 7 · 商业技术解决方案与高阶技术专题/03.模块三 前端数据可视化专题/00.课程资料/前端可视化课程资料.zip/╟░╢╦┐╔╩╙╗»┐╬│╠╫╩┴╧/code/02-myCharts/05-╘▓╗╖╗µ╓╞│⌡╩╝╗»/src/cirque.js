let Cirque = function (percent) {

  let o = this.defaultParam

  console.log(o)
}

export default Cirque

