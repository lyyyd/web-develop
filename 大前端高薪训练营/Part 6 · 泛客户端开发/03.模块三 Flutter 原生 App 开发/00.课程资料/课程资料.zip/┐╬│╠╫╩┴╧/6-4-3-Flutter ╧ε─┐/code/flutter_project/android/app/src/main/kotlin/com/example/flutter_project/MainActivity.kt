package com.example.flutter_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
