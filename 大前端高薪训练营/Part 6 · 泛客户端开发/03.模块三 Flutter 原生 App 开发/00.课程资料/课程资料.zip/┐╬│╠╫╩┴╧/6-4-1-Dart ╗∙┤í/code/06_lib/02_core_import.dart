import 'dart:math';
// import 'dart:core'; // core 库会被默认引入

void main() {
  print(pi);

  print(min(3,6));
  print(max(3,6));
}