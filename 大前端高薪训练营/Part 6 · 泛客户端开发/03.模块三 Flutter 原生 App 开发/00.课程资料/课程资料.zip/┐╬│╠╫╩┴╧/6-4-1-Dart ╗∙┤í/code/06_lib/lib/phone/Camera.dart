// 与主库建立联系
part of phone;

class Camera {
  String name = "摄像头";

  void info() {
    print('我是摄像头');
  }
}