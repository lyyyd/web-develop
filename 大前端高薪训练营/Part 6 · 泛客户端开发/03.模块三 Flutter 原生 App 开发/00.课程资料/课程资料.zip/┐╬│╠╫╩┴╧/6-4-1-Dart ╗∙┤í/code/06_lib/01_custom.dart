import 'lib/MyCustom.dart';

void main() {
  MyCustom mc = new MyCustom();

  mc.info();
  print(MyCustom.version);
}