void f1() {
  print('f1 of function is running');
}

void hello() {
  print('Hello World');
}