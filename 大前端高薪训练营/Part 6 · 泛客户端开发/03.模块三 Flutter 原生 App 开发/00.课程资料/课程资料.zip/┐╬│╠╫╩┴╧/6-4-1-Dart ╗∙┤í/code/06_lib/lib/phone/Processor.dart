// 与主库建立联系
part of phone;

class Processor {
  String name = "处理器";

  void info() {
    print('我是处理器');
  }
}