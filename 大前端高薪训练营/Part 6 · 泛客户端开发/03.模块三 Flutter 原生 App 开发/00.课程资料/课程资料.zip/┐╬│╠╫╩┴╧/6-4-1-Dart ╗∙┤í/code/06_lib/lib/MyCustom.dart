// library MyCustom;
library my_custom; // 建议写成小写字母+下划线的形式

class MyCustom {
  String name = "MyCustom";
  static num version = 1.0;

  void info() {
    print('我是自定义库');
  }
}