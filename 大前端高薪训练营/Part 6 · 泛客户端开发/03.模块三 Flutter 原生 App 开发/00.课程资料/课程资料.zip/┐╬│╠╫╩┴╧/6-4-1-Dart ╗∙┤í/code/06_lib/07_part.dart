import 'lib/phone/main.dart' as phone;

void main() {
  phone.main();
}