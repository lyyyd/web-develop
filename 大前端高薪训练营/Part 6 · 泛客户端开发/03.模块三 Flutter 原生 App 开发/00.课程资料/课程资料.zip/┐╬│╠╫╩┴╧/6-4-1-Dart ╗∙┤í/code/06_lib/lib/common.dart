void f1() {
  print('f1 is running');
}

void f2() {
  print('f2 is running');
}

void f3() {
  print('f3 is running');
}