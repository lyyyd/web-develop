import React, { Component } from 'react'
import { Text, StyleSheet, View } from 'react-native'

export default class About extends Component {
  render() {
    return (
      <View>
        <Text> Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ea, iusto enim laboriosam modi nisi tempora optio molestias nulla sit nobis dolor in necessitatibus provident autem dicta eligendi distinctio temporibus! Obcaecati veniam nobis in voluptas animi reiciendis ad asperiores ipsam omnis itaque fugiat a recusandae vel unde maxime, consectetur expedita hic nisi labore quam dolor ut. Fugit repudiandae impedit repellendus consectetur et, vitae recusandae fuga vero rem aspernatur corporis iusto ab sed, exercitationem praesentium illum porro amet cum? Praesentium delectus nostrum saepe, facilis repudiandae atque. Ab quos nobis asperiores fugiat nam id temporibus corrupti ullam aliquid quae tenetur doloribus, tempore quasi! </Text>
      </View>
    )
  }
}

const styles = StyleSheet.create({})
