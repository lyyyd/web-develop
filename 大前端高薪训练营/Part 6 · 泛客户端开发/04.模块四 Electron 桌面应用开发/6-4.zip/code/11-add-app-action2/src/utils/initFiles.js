const initFiles = [
  {
    id: '1',
    title: '文件1',
    body: '## 文件1内容',
    createTime: '12345678'
  },
  {
    id: '2',
    title: '文件2',
    body: '拉勾教育666',
    createTime: '12345678'
  },
  {
    id: '3',
    title: '文件3',
    body: '前端前端',
    createTime: '12345678'
  },
  {
    id: '4',
    title: '标题1',
    body: '44444',
    createTime: '12345678'
  },
  {
    id: '5',
    title: '标题2',
    body: '555555',
    createTime: '12345678'
  },
]

export default initFiles