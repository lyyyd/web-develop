
function App() {
  return (
    <div className="App">
      <h2>拉勾教育</h2>
    </div>
  )
}

export default App;
