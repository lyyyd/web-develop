const initFiles = [
  {
    id: '1',
    title: '文件1',
    body: '## 文件1内容',
    createTime: '12345678'
  },
  {
    id: '2',
    title: '文件2',
    body: '拉勾教育666',
    createTime: '12345678'
  },
  {
    id: '3',
    title: '标题3',
    body: '前端前端',
    createTime: '12345678'
  },
]

export default initFiles