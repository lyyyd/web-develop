## React 数据流方案 Redux Mobx

------

### 编码题

使用 react + mobx 完成下面的摘苹果/吃苹果效果

具体效果参考网址 https://ftp.bmp.ovh/imgs/2020/11/3fd8e34eaf0e3e14.gif

资源下载地址

https://github.com/cuiweijun/redux-mobx-immutable-cart/tree/master/src



作业代码目录：`code/mobx-demo`