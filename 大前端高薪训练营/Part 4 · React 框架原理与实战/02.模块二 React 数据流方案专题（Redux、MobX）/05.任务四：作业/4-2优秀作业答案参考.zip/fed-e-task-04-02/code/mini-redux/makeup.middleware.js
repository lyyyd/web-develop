function makeup (store) {
    return function (next) {
      return function (action) {
        console.log('makeup');
        next(action)
      }
    }
  }