import { makeAutoObservable } from "mobx";

class TodoStore {
  todos = [];
  isAllCompleted = false;
  filter = "All";
  constructor() {
    makeAutoObservable(this);
  }

  addTodo = (taskName) => {
    this.todos.push({
      taskName,
      isCompleted: false,
    });
  };

  deleteTodo = (index) => {
    this.todos.splice(index, 1);
  };

  changeCompleted = (index, flag) => {
    this.todos[index].isCompleted = flag;
  };

  clearCompleted = () => {
    this.todos = this.todos.filter((todo) => !todo.isCompleted);
  };

  get allCompleted() {
    const res = this.todos.every((todo) => todo.isCompleted);
    return res;
  }

  changeAllCompleted = (flag) => {
    this.todos.forEach((todo) => (todo.isCompleted = flag));
  };

  changeFilter = (filter) => {
    this.filter = filter;
  };

  get filterTodos() {
    switch (this.filter) {
      case "Active":
        return this.todos.filter((todo) => !todo.isCompleted);
      case "Completed":
        return this.todos.filter((todo) => todo.isCompleted);
      default:
        return this.todos;
    }
  }

  get filterTodosCount() {
    return this.filterTodos.length;
  }
}

export default new TodoStore();
