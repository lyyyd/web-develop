import CountClass from "./components/CountClass";
import CountFunction from "./components/CountFunction";

function MobxCount() {
  return (
    <div>
      <CountFunction />
      <CountClass />
    </div>
  );
}

export default MobxCount;
