import TodoAdd from "./components/TodoAdd";
import TodoList from "./components/TodoList";
import TodoExtra from "./components/TodoExtra";
import './style.css';

function MobxTodo() {
  return (
    <div className="todoapp">
      <TodoAdd />
      <TodoList />
      <TodoExtra />
    </div>
  );
}

export default MobxTodo;
