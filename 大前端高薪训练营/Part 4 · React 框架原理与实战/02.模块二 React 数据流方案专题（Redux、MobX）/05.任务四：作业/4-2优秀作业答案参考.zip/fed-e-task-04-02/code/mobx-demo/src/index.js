import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import AppRouter from "./router/AppRouter";
import { Provider } from 'mobx-react'
import todoStore from './stores/TodoStore'
import countStore from './stores/countStore'
import appleStore from './stores/appleStore'

ReactDOM.render(
  <Provider
    todoStore={todoStore}
    countStore={countStore}
    appleStore={appleStore}>
    <AppRouter />
  </Provider>,
  document.getElementById('root')
);