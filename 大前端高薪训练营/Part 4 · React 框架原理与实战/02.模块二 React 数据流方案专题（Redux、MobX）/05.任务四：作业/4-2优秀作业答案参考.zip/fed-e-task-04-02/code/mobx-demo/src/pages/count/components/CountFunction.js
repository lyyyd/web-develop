import { inject, observer } from "mobx-react";
import React from 'react'
const Count = ({countStore}) => (
  <div>
    <span>{countStore.count}</span>
    <button className="count-btn" onClick={countStore.decrement}> - </button>
  </div>
)

export default inject('countStore')(observer(Count))