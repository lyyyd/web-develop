import React, { Component } from "react";
import { inject, observer } from "mobx-react";

@inject("countStore")
@observer
class CountDemo extends Component {
  componentDidMount() {
    const { getData } = this.props.countStore;
    getData();
  }
  render() {
    const {
      count,
      increment,
      decrement,
      getResult,
      users,
      username,
      changeUsername,
    } = this.props.countStore;
    const countStore = this.props.countStore
    return (
      <div>
        <button className="count-btn" onClick={() => countStore.increment()}>
          +
        </button>
        <span>{count}</span>
        <button className="count-btn" onClick={decrement}>
          -
        </button>
        <span>{getResult}</span>
        <div>
          <input
            type="text"
            value={username}
            onChange={(e) => changeUsername(e.target.value)}
          />
        </div>
        <div>
          {users.map((user) => (
            <div key={user.id}>
              <span>{user.id}</span>
              <span>{user.login}</span>
            </div>
          ))}
        </div>
      </div>
    );
  }
}

export default CountDemo;
