// import { camelCase, capitalize } from 'lodash'

// const result = camelCase('Hello world')

// console.log(result)


// import _ from 'lodash'

// const res = _.camelCase('HELLO WOLRD')

// _.capitalize('hssss sss')

// const cache: Dict<string> = {
//   foo: '234',
//   bar: 'ass'
// }



// import logo from './logo.png'

// // import './style.css'

// import styles from './style.module.css'

// styles.container


// import express from 'express'

// // express

// import ca from 'caz'
