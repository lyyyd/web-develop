/**
 *
 * @typedef {'open' | 'close'} Status
 */

/**
 * @param {number} a param 1
 * @param {number} b param 2
 * @returns {number}
 */
export const add = (a, b) => a + b


add('123', '213')
