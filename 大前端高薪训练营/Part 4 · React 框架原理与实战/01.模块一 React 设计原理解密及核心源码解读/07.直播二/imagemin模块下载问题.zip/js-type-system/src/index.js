
// @ts-check
import { add } from './utils'

const res = add(1, 2)


let str = '123'

str = 123