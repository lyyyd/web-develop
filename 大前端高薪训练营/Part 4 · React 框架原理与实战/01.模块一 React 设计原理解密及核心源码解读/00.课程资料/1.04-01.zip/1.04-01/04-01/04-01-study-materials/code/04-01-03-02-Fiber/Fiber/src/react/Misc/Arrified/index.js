const arrified = arg => (Array.isArray(arg) ? arg : [arg])

export default arrified
