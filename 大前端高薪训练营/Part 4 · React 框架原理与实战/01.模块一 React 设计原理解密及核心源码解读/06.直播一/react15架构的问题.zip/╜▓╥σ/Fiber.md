#### 1. Fiber 出现的目的是什么

为了提高 React 渲染页面的效率。

<img src="./images/01.gif" align="left"/>



<img src="./images/02.gif" align="left"/>



#### 2. 在 Fiber 出现之前, React 存在什么问题

在 React 16 版本之前是没有 Fiber 的，React 采用的是 Virtual DOM 以提高操作 DOM 的效率。 Virtual DOM 实际上就是 JavaScript 对象，用来描述真实 DOM 对象长成什么样子，通过 Virtual DOM 对比可以找出 DOM 对象的差异部分，从而只将差异部分更新到页面中，避免更新整体 DOM 对象以提高性能。但是在 Virtual DOM 渲染为真实 DOM，在 Virtual DOM 比对的过程中 React 使用了递归，递归调用的过程不能被终止，如果 Virtual DOM 的层级比较深，递归比对的过程就会长期占用主线程，而 JavaScript 又是单线程，不能同时执行多个任务，而且 JavaScript 执行和 UI 渲染又是互斥的，用户要么看到的就是空白界面，要么就是有界面但是不能响应任务操作处于卡顿状态，从而产生性能问题, 用户体验差。

核心就是递归比对的过程长期占用主线程产生了性能问题。

<img src="./images/06.png" align="left"/>



<video controls>
  <source src="./video/Recursion.mp4" type="video/mp4">
</video>



#### 3. 虚拟 DOM 是如何被转换为真实 DOM 的

[babel repl](https://babeljs.io/repl)

```react
const jsx = (
  <div id="a1">
    <div id="b1">
      <div id="c1"></div>
      <div id="c2"></div>
    </div>
    <div id="b2"></div>
  </div>
)
```

```react
function render(vdom, container) {
  // 创建 DOM 元素
  const element = document.createElement(vdom.type)
  // 为元素添加属性 (刨除 children)
  Object.keys(vdom.props)
    .filter(propName => propName !== "children")
    .forEach(propName => (element[propName] = vdom.props[propName]))

  // 递归创建子元素
  if (Array.isArray(vdom.props.children)) {
    vdom.props.children.forEach(child => render(child, element))
  }
  // 将子元素追加到父级
  container.appendChild(element)
}

render(jsx, document.getElementById("root"))
```

#### 4. Fiber 如何解决性能问题

在 Fiber 架构中 React 放弃了递归调用，采用循环模拟递归，循环可以随时被中断。React 利用浏览器空闲时间执行比对任务，如果有高优先级任务比如用户事件，React 会中断比对任务，优先执行用户事件。解决了 React 执行比对任务长期占用主线程的问题。

<img src="./images/07.jpg" align="left"/>



#### 5. 什么是渲染帧

渲染帧是指浏览器一次完整的绘制过程，绘制一帧的时间只有控制在 16ms 以内，用户才不会有卡顿的感觉。

页面是显示在屏幕设备中的，只有屏幕设备刷新以后才能看到浏览器的绘制结果。

屏幕设备是不断进行刷新的，只不过速度太快, 肉眼感受不到刷新的过程。

<img src="./images/03.jpeg" align="left"/>

主流的屏幕设备刷新率是 1 秒 60 次，1000 / 60 = 16ms，屏幕设备 16ms 刷新一次，就是说屏幕设备留给浏览器绘制一帧的时间为 16ms，如果浏览器绘制一帧的时间超过 16ms，就表示丢帧了，用户就会觉得卡顿。

比如用户滚动页面的过程中，浏览器需要不断重新绘制，屏幕设备需要不断刷新，用户才能看到最新的页面内容。只有浏览器的绘制每一帧的速率和屏幕设备刷新的速率保持一致。用户看的页面才是流畅的。

一帧时间内浏览器要做的事情：脚本执行，样式计算，布局，重绘，合成。

<img src="./images/04.png"/>

如果在某一项内容执行时间过长，浏览器会推迟渲染，造成丢帧卡顿，就没有剩余时间。如果浏览器绘制一帧的时间小于了 16ms，就表示有空余时间了。

空余时间：16ms - 绘制一帧的时间。

#### 6. 什么是 Fiber

1. Fiber 是一个执行单元

   在 React 15 中，将 VirtualDOM 整体看成一个任务进行递归处理，任务整体庞大执行耗时不能中断。

   在 React 16 中，将整个任务拆分成了一个一个小的任务进行处理。每一个小的任务就表示一个执行单元。每一个小的任务指的就是一个 Fiber 节点的构建。一个 Fiber 节点的构建就是一个执行单元。执行单元在浏览器的空闲时间被执行，且可以随时被终止。React 会在每个执行单元执行完成后，检查是否还有空余时间，如果没有就交还主线程的控制权。

   <img src="./images/05.png" align="left" width="60%"/>

2. Fiber 是一种数据结构

   当任务单元的执行被终止后, 下次再开始执行任务单元时如何找到要执行的任务单元?

   当 React 再一次开始执行任务单元时，是通过链表结构找到的下一个要执行的任务单元，Fiber 对象就是链表中的每一个执行单元。

   要构建链表结构，需要知道每一个节点的父级节点是谁，要知道他的子级节点是谁，要知道他的下一个兄弟节点是谁。

   Fiber 其实就是 JavaScript 对象，在这个对象中有 child 属性表示节点的子节点，有 sibling 属性表示节点的下一个兄弟节点，有 return 属性表示节点的父级节点。

   ```javascript
   type Fiber = {
     // 组件类型 div、span、组件构造函数
     type: any,
     // DOM 对象
     stateNode: any,  
     // 指向自己的父级 Fiber 对象
     return: Fiber | null,
     // 指向自己的第一个子级 Fiber 对象
     child: Fiber | null,
     // 指向自己的下一个兄弟 iber 对象
     sibling: Fiber | null,
   };
   ```

   <img src="./images/08.png"/>



#### 7. Fiber 的工作方式

Fiber 的工作分为两个阶段：render 阶段和 commit 阶段。

render 阶段：构建 Fiber 对象，构建链表结构，将需要执行 DOM 操作的 Fiber 对象放入链表结构中，可中断。

commit 阶段：根据构建好的链表进行 DOM 操作，不可中断。

<img src="./images/07.png" align="left"/>

#### 8. 实现 Fiber

```react
import React from "react"

const jsx = (
  <div id="a1">
    <div id="b1">
      <div id="c1"></div>
      <div id="c2"></div>
    </div>
    <div id="b2"></div>
  </div>
)

const container = document.getElementById("root")

/**
 * 1. 为每一个节点构建 Fiber 对象
 * 2. 构建要执行 DOM 操作的 Fiber 链表
 * 3. 提交 Fiber 链接
 */

// 创建根元素 Fiber 对象
const workInProgressRoot = {
  stateNode: container,
  props: {
    children: [jsx]
  }
}

let nextUnitOfWork = workInProgressRoot

function workLoop(deadline) {
  // 如果下一个要构建的执行单元存在并且浏览器有空余时间
  while (nextUnitOfWork && deadline.timeRemaining() > 0) {
    // 构建执行单元并返回新的执行单元
    nextUnitOfWork = performUnitOfWork(nextUnitOfWork)
  }
  // 如果所有的执行单元都已经构建完成
  if (!nextUnitOfWork) {
    // 进入到第二个阶段 执行 DOM 操作
    commitRoot()
  }
}
// Fiber 工作的第一个阶段
function performUnitOfWork(workInProgress) {
  // 构建阶段向下走的过程
  // 1. 创建当前 Fiber 节点的 DOM 对象并存储在 stateNode 属性中
  // 2. 构建子级 Fiber 对象
  beginWork(workInProgress)
  // 如果子级存在
  if (workInProgress.child) {
    // 返回子级 构建子级的子级
    return workInProgress.child
  }
  // 开始构建阶段向上走的过程
  // 如果父级存在
  while (workInProgress) {
    // 构建 Fiber 链表
    completeUnitOfWork(workInProgress)
    // 如果同级存在
    if (workInProgress.sibling) {
      // 返回同级 构建同级的子级
      return workInProgress.sibling
    }
    // 同级不存在 退回父级 看父级是否有同级
    workInProgress = workInProgress.return
  }
}

function beginWork(workInProgress) {
  // 如果 Fiber 对象没有存储其对应的 DOM 对象
  if (!workInProgress.stateNode) {
    // 创建 DOM 对象并存储在 Fiber 对象中
    workInProgress.stateNode = document.createElement(workInProgress.type)
    // 为 DOM 对象添加属性
    for (let attr in workInProgress.props) {
      if (attr !== "children") {
        workInProgress.stateNode[attr] = workInProgress.props[attr]
      }
    }
  }
  // 创建子级 Fiber 对象
  if (Array.isArray(workInProgress.props.children)) {
    // 记录上一次创建的子级 Fiber 对象
    let previousFiber = null
    // 遍历子级
    workInProgress.props.children.forEach((child, index) => {
      // 创建子级 Fiber 对象
      let childFiber = {
        type: child.type,
        props: child.props,
        return: workInProgress,
        effectTag: "PLACEMENT"
      }
      // 第一个子级挂载到父级的 child 属性中
      if (index === 0) {
        workInProgress.child = childFiber
      } else {
        // 其他子级挂载到自己的上一个兄弟的 sibling 属性中
        previousFiber.sibling = childFiber
      }
      // 更新上一个子级
      previousFiber = childFiber
    })
  }
}

function completeUnitOfWork(workInProgress) {
  let returnFiber = workInProgress.return

  if (returnFiber) {
    // 链头上移
    if (!returnFiber.firstEffect) {
      returnFiber.firstEffect = workInProgress.firstEffect
    }
    // lastEffect 上移
    if (!returnFiber.lastEffect) {
      returnFiber.lastEffect = workInProgress.lastEffect
    }
    // 构建链表
    if (workInProgress.effectTag) {
      if (returnFiber.lastEffect) {
        returnFiber.lastEffect.nextEffect = workInProgress
      } else {
        returnFiber.firstEffect = workInProgress
      }
      returnFiber.lastEffect = workInProgress
    }
  }
}

// Fiber 工作的第二阶段
function commitRoot() {
  // 获取链表中第一个要执行的 DOM 操作
  let currentFiber = workInProgressRoot.firstEffect
  // 判断要执行 DOM 操作的 Fiber 对象是否存在
  while (currentFiber) {
    // 执行 DOM 操作
    currentFiber.return.stateNode.appendChild(currentFiber.stateNode)
    // 从链表中取出下一个要执行 DOM 操作的 Fiber 对象
    currentFiber = currentFiber.nextEffect
  }
}

// 在浏览器空闲的时候开始构建
requestIdleCallback(workLoop)
```

#### 9. 构建 Fiber 链表

1. 通过链表可以按照顺序存储内容
2. 链表中存储的是即将要执行 DOM 操作的 Fiber 对象
3. 链表的顺序是由 DOM 操作的顺序决定的，c1 是第一个要执行 DOM 操作的所以它是链头
4. 链头要存储在 Root 中，但 Root 位于遍历顺序的最后，所以链头需要一层一层向上传递
5. 在构建 Fiber 链表的过程中，需要通过 lastEffect 存储最新构建的 Fiber，下次构建时通过 lastEffect 向链的后面添加 Fiber 对象。lastEffect 是存储在父级上的，父级也会变成当前要处理的 Fiber， 所以 LastEffect 也需要一层一层向上传递。 

<img src="./images/12.png" align="left"/>



<img src="./images/11.png" align="left"/>



<img src="./images/09.png" align="left"/>



<img src="./images/10.png" align="left"/>