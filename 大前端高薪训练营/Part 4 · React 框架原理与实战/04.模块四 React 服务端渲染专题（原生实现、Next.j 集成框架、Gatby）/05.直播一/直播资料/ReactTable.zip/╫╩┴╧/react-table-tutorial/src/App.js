import BasicTable from "./components/BasicTable"

function App() {
  return <BasicTable />
}

export default App
