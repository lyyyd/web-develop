// 引入列信息数组
import { COLUMNS } from "./columns"
// 引入模拟数据
import MOCK_DATA from "./MOCK_DATA.json"
// useMemo: 缓存值
import { useMemo } from "react"
// useTable: 核心方法, 用于创建表格实例对象
import { useTable } from "react-table"
// 引入表格样式
import "./table.css"

const BasicTable = () => {
  // 缓存列信息数组
  const columns = useMemo(() => COLUMNS, [])
  // 缓存模拟数据
  const data = useMemo(() => MOCK_DATA, [])
  // 创建表格实例对象
  // getTableProps: 获取 table 标记属性
  // getTableBodyProps: 获取 tbody 标记属性
  // headerGroups: 获取页头信息
  // footerGroups: 获取页脚信息
  // rows: 表格中要展示的数据
  // prepareRow: 计算要显示的行信息
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    footerGroups,
    rows,
    prepareRow
  } = useTable({
    columns,
    data
  })
  return (
    <>
      <table {...getTableProps()}>
        <thead>
          {headerGroups.map(headerGroup => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map(column => (
                <th {...column.getHeaderProps()}>
                  {column.render("Header")}
                </th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody {...getTableBodyProps()}>
          {rows.map(row => {
            prepareRow(row)
            return (
              <tr {...row.getRowProps()}>
                {row.cells.map(cell => (
                  <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
                ))}
              </tr>
            )
          })}
        </tbody>
        <tfoot>
          {footerGroups.map(footerGroup => (
            <tr {...footerGroup.getFooterGroupProps()}>
              {footerGroup.headers.map(column => (
                <td {...column.getFooterProps()}>
                  {column.render("Footer")}
                </td>
              ))}
            </tr>
          ))}
        </tfoot>
      </table>
    </>
  )
}

export default BasicTable
