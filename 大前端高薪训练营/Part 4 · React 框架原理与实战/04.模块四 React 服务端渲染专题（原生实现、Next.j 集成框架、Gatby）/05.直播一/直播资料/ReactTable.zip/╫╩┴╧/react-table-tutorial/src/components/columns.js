export const COLUMNS = [
  {
    Header: "ID",
    accessor: "id",
    Footer: "ID"
  },
  {
    Header: "名",
    accessor: "first_name",
    Footer: "名"
  },
  {
    Header: "姓",
    accessor: "last_name",
    Footer: "姓"
  },
  {
    Header: "出生日期",
    accessor: "data_of_birth",
    Footer: "出生日期"
  },
  {
    Header: "国家",
    accessor: "country",
    Footer: "国家"
  },
  {
    Header: "电话",
    accessor: "phone",
    Footer: "电话"
  }
]
