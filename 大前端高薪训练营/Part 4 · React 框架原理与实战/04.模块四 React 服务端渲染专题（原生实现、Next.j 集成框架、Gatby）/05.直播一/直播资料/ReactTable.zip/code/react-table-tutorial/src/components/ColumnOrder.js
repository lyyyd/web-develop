// 引入表格中要展示的数据
import MOCK_DATA from "./MOCK_DATA.json"
// 引入列信息
import { COLUMNS } from "./columns"
import { useMemo } from "react"
import { useTable, useColumnOrder } from "react-table"
import "./table.css"

const ColumnOrder = () => {
  const data = useMemo(() => MOCK_DATA, [])
  const columns = useMemo(() => COLUMNS, [])
  // 创建表格实例对象
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    footerGroups,
    rows,
    prepareRow,
    setColumnOrder
  } = useTable(
    {
      columns,
      data
    },
    useColumnOrder
  )
  return (
    <>
      <button
        onClick={() =>
          setColumnOrder([
            "phone",
            "id",
            "country",
            "last_name",
            "first_name",
            "data_of_birth"
          ])
        }
      >
        更改列顺序
      </button>
      <table {...getTableProps()}>
        <thead>
          {headerGroups.map(headerGroup => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map(column => (
                <th {...column.getHeaderProps()}>
                  {column.render("Header")}
                </th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody {...getTableBodyProps()}>
          {rows.map(row => {
            prepareRow(row)
            return (
              <tr {...row.getRowProps()}>
                {row.cells.map(cell => (
                  <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
                ))}
              </tr>
            )
          })}
        </tbody>
        <tfoot>
          {footerGroups.map(footGroup => (
            <tr {...footGroup.getFooterGroupProps()}>
              {footGroup.headers.map(column => (
                <td {...column.getFooterProps()}>
                  {column.render("Footer")}
                </td>
              ))}
            </tr>
          ))}
        </tfoot>
      </table>
    </>
  )
}

export default ColumnOrder
