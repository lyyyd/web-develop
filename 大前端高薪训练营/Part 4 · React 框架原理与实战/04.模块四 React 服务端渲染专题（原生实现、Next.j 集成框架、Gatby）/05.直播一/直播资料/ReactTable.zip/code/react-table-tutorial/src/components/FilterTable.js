// 引入表格中要展示的数据
import MOCK_DATA from "./MOCK_DATA.json"
// 引入列信息
import { COLUMNS } from "./columns"
import { useMemo } from "react"
import { useTable, useGlobalFilter, useFilters } from "react-table"
import "./table.css"
import GlobalFilter from "./GlobalFilter"
import ColumnFilter from "./ColumnFilter"

const FilterTable = () => {
  const data = useMemo(() => MOCK_DATA, [])
  const columns = useMemo(() => COLUMNS, [])
  const defaultColumn = useMemo(() => ({ Filter: ColumnFilter }), [])

  // 创建表格实例对象
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    footerGroups,
    rows,
    prepareRow,
    setGlobalFilter,
    state
  } = useTable(
    {
      columns,
      data,
      defaultColumn
    },
    useFilters,
    useGlobalFilter
  )

  const { globalFilter } = state

  return (
    <>
      <GlobalFilter filter={globalFilter} setFilter={setGlobalFilter} />
      <table {...getTableProps()}>
        <thead>
          {headerGroups.map(headerGroup => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map(column => (
                <th {...column.getHeaderProps()}>
                  {column.render("Header")}
                  {column.canFilter ? column.render("Filter") : null}
                </th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody {...getTableBodyProps()}>
          {rows.map(row => {
            prepareRow(row)
            return (
              <tr {...row.getRowProps()}>
                {row.cells.map(cell => (
                  <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
                ))}
              </tr>
            )
          })}
        </tbody>
        <tfoot>
          {footerGroups.map(footGroup => (
            <tr {...footGroup.getFooterGroupProps()}>
              {footGroup.headers.map(column => (
                <td {...column.getFooterProps()}>
                  {column.render("Footer")}
                </td>
              ))}
            </tr>
          ))}
        </tfoot>
      </table>
    </>
  )
}

export default FilterTable
