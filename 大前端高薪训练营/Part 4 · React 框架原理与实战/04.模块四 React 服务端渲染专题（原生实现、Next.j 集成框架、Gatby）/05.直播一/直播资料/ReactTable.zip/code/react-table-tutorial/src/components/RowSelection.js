// 引入表格中要展示的数据
import MOCK_DATA from "./MOCK_DATA.json"
// 引入列信息
import { COLUMNS } from "./columns"
import { useMemo } from "react"
import { useTable, useRowSelect } from "react-table"
import "./table.css"
import Checkbox from "./Checkbox"

const RowSection = () => {
  const data = useMemo(() => MOCK_DATA, [])
  const columns = useMemo(() => COLUMNS, [])
  // 创建表格实例对象
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    footerGroups,
    rows,
    prepareRow,
    selectedFlatRows
  } = useTable(
    {
      columns,
      data
    },
    useRowSelect,
    hooks => {
      hooks.visibleColumns.push(columns => {
        return [
          {
            id: "selction",
            Header: ({ getToggleAllRowsSelectedProps }) => (
              <Checkbox {...getToggleAllRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
              <Checkbox {...row.getToggleRowSelectedProps()} />
            )
          },
          ...columns
        ]
      })
    }
  )
  return (
    <>
      <table {...getTableProps()}>
        <thead>
          {headerGroups.map(headerGroup => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map(column => (
                <th {...column.getHeaderProps()}>
                  {column.render("Header")}
                </th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody {...getTableBodyProps()}>
          {rows.map(row => {
            prepareRow(row)
            return (
              <tr {...row.getRowProps()}>
                {row.cells.map(cell => (
                  <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
                ))}
              </tr>
            )
          })}
        </tbody>
        <tfoot>
          {footerGroups.map(footGroup => (
            <tr {...footGroup.getFooterGroupProps()}>
              {footGroup.headers.map(column => (
                <td {...column.getFooterProps()}>
                  {column.render("Footer")}
                </td>
              ))}
            </tr>
          ))}
        </tfoot>
      </table>
      <div>
        <pre>
          {JSON.stringify(
            { flatRows: selectedFlatRows.map(row => row.original) },
            null,
            2
          )}
        </pre>
      </div>
    </>
  )
}

export default RowSection
