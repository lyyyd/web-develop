import { useAsyncDebounce } from "react-table"
import { useState } from "react"

const GlobalFilter = ({ filter, setFilter }) => {
  const [value, setValue] = useState(filter)
  const onChange = useAsyncDebounce(() => {
    setFilter(value)
  }, 1000)
  return (
    <div>
      搜索:{" "}
      <input
        type="text"
        value={filter}
        onChange={event => {
          setValue(event.target.value)
          onChange()
        }}
      />
    </div>
  )
}

export default GlobalFilter
