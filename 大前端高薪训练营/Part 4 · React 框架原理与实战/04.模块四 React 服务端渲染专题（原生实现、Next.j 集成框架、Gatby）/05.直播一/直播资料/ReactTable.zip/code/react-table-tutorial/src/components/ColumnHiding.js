// 引入表格中要展示的数据
import MOCK_DATA from "./MOCK_DATA.json"
// 引入列信息
import { COLUMNS } from "./columns"
import { useMemo } from "react"
import { useTable } from "react-table"
import Checkbox from "./Checkbox"
import "./table.css"

const ColumnHiding = () => {
  const data = useMemo(() => MOCK_DATA, [])
  const columns = useMemo(() => COLUMNS, [])
  // 创建表格实例对象
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    footerGroups,
    rows,
    prepareRow,
    getToggleHideAllColumnsProps,
    allColumns
  } = useTable({
    columns,
    data
  })
  return (
    <>
      <div>
        <Checkbox {...getToggleHideAllColumnsProps()} /> 显示/隐藏所有列
        {allColumns.map(column => (
          <div key={column.id}>
            <Checkbox {...column.getToggleHiddenProps()} /> {column.Header}
          </div>
        ))}
      </div>
      <table {...getTableProps()}>
        <thead>
          {headerGroups.map(headerGroup => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map(column => (
                <th {...column.getHeaderProps()}>
                  {column.render("Header")}
                </th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody {...getTableBodyProps()}>
          {rows.map(row => {
            prepareRow(row)
            return (
              <tr {...row.getRowProps()}>
                {row.cells.map(cell => (
                  <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
                ))}
              </tr>
            )
          })}
        </tbody>
        <tfoot>
          {footerGroups.map(footGroup => (
            <tr {...footGroup.getFooterGroupProps()}>
              {footGroup.headers.map(column => (
                <td {...column.getFooterProps()}>
                  {column.render("Footer")}
                </td>
              ))}
            </tr>
          ))}
        </tfoot>
      </table>
    </>
  )
}

export default ColumnHiding
