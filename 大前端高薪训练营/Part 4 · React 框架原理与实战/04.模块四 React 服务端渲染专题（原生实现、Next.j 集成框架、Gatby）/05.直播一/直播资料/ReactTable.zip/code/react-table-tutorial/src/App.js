import StickyTable from "./components/StickyTable"

function App() {
  return <StickyTable />
}

export default App
