import dateformat from "dateformat"

export const COLUMNS = [
  {
    Header: "ID",
    accessor: "id",
    Footer: "ID",
    disableFilters: true,
    sticky: "left"
  },
  {
    Header: "名",
    accessor: "first_name",
    Footer: "名",
    sticky: "left"
  },
  {
    Header: "姓",
    accessor: "last_name",
    Footer: "姓",
    sticky: "left"
  },
  {
    Header: "出生日期",
    accessor: "data_of_birth",
    Footer: "出生日期",
    Cell: ({ value }) => dateformat(value, "yyyy-mm-dd")
  },
  {
    Header: "国家",
    accessor: "country",
    Footer: "国家"
  },
  {
    Header: "电话",
    accessor: "phone",
    Footer: "电话"
  },
  {
    Header: "邮件",
    Footer: "邮件",
    accessor: "email"
  },
  {
    Header: "年龄",
    Footer: "年龄",
    accessor: "age",
    sticky: "right"
  }
]

export const COLUMNS_GROUPS = [
  {
    Header: "ID",
    accessor: "id",
    Footer: "ID"
  },
  {
    Header: "姓名",
    Footer: "姓名",
    columns: [
      {
        Header: "名",
        accessor: "first_name",
        Footer: "名"
      },
      {
        Header: "姓",
        accessor: "last_name",
        Footer: "姓"
      }
    ]
  },
  {
    Header: "一般信息",
    Footer: "一般信息",
    columns: [
      {
        Header: "出生日期",
        accessor: "data_of_birth",
        Footer: "出生日期"
      },
      {
        Header: "国家",
        accessor: "country",
        Footer: "国家"
      },
      {
        Header: "电话",
        accessor: "phone",
        Footer: "电话"
      }
    ]
  }
]
