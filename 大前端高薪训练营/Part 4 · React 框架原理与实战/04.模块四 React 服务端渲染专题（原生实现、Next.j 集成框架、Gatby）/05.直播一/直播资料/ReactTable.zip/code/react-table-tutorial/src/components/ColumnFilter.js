const ColumnFilter = ({ column }) => {
  const { filterValue, setFilter } = column
  return (
    <div>
      搜索:{" "}
      <input
        type="text"
        value={filterValue}
        onChange={event => setFilter(event.target.value)}
      />
    </div>
  )
}

export default ColumnFilter
