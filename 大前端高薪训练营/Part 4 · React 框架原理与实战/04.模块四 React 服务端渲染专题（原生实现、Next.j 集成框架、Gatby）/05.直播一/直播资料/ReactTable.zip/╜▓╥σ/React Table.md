## [React Table](https://react-table.tanstack.com/)

### 1. 概述

#### 1.1 为什么学习 React Table

1. 使用表格进行数据可视化是不可避免的。
2. 构建自己的表格组件可能会充满挑战。

#### 1.2 React Table

React Table 用于构建强大的可扩展的数据表格，是一组钩子函数的集合，使用什么功能就调用什么钩子函数。

1. React Table 采用无头设计，即不提供 UI 样式，开发者可以完全控制表格如何呈现，所以它不是表格组件，而是表格的实用工具集。
2. 功能强大，提供了过滤，排序，分组，分页和列固定等等功能。
3. React Table 是可扩展的，因为它拥有自己的插件系统，使开发者可以覆盖或扩展React Table 内部的逻辑步骤，阶段或过程。

` yarn add react-table`

`yarn add react-table dateformat react-table-sticky styled-components`

### 2. Basic Table

<img src="./images/03.png"/>

1. 获取要展示的数据。 生成模拟数据：[mockaroo](https://mockaroo.com/)

   <img src="./images/01.png"/>

2. 定义表格的列。

3. 使用 react-table 创建表格实例对象并传入要展示的数据和列信息。

4. 使用 HTML 定义一个基本的表格结构。

5. 将表格实例对象信息赋值给 HTML，展示数据。

6. 引入 CSS 文件为表格添加样式 [样式来源](https://www.w3schools.com/css/tryit.asp?filename=trycss_table_fancy)。

```react
// columns.js
// Header: 定义页头列名称
// accessor: 定义列关联的数据属性
export const COLUMNS = [
  {
    Header: "ID",
    accessor: "id"
  },
  {
    Header: "名",
    accessor: "first_name"
  },
  {
    Header: "姓",
    accessor: "last_name"
  },
  {
    Header: "出生日期",
    accessor: "date_of_birth"
  },
  {
    Header: "国家",
    accessor: "country"
  },
  {
    Header: "电话",
    accessor: "phone"
  }
]
```

```react
// BasicTable.js
import { COLUMNS } from "./columns"
import MOCK_DATA from "./MOCK_DATA.json"
import { useMemo } from "react"
import { useTable } from "react-table"
import "./table.css"

const BasicTable = () => {
  // 缓存列信息
  const columns = useMemo(() => COLUMNS, [])
  // 缓存表格数据
  const data = useMemo(() => MOCK_DATA, [])
  // 创建表格实例对象
  const {
    // 获取 table 标记属性
    getTableProps,
    // 获取 tbody 标记属性
    getTableBodyProps,
    // 获取表格页头信息
    headerGroups,
    // 获取表格中要展示的数据
    rows,
    // 计算要显示的行信息 (比如分页, 当前页要显示哪些行)
    prepareRow
  } = useTable({
    columns,
    data
  })
  return (
    <>
      <table {...getTableProps()}>
        <thead>
          {headerGroups.map(headerGroup => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map(column => (
                <th {...column.getHeaderProps()}>
                  {column.render("Header")}
                </th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody {...getTableBodyProps()}>
          {rows.map(row => {
            prepareRow(row)
            return (
              <tr {...row.getRowProps()}>
                {row.cells.map(cell => (
                  <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
                ))}
              </tr>
            )
          })}
        </tbody>
      </table>
    </>
  )
}

export default BasicTable
```

```css
table {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

table td,
table th {
  border: 1px solid #ddd;
  padding: 8px;
}

table tr:nth-child(even) {
  background-color: #f2f2f2;
}

table tr:hover {
  background-color: #ddd;
}

table th, tfoot td {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #4caf50;
  color: white;
}
```

### 3. 创建表格页脚

<img src="./images/04.png" />

```json
// columns.js
// Footer: 定义页脚列名称
export const COLUMNS = [
  {
    Footer: "ID",
  },
  {
    Footer: "名",
  },
  {
    Footer: "姓",
  },
  {
    Footer: "出生日期",
  },
  {
    Footer: "国家",
  },
  {
    Footer: "电话",
  }
]
```

```react
const BasicTable = () => {
  // 获取表格页脚信息
  const { footerGroups } = useTable({})
  return (
    <table>
      <tfoot>
        {footerGroups.map(footerGroup => (
          <tr {...footerGroup.getFooterGroupProps()}>
            {footerGroup.headers.map(column => (
              <th {...column.getFooterProps()}>{column.render("Footer")}</th>
            ))}
          </tr>
        ))}
      </tfoot>
    </table>
  )
}
```

### 4. 创建表格分组

<img src="./images/05.png" />

```json
// columns.js
export const COLUMNS_GROUP = [
  {
    Header: "ID",
    Footer: "ID",
    accessor: "id"
  },
  {
    Header: "Name",
    Footer: "Name",
    columns: [
      {
        Header: "First Name",
        Footer: "First Name",
        accessor: "first_name"
      },
      {
        Header: "Last Name",
        Footer: "Last Name",
        accessor: "last_name"
      }
    ]
  },
  {
    Header: "Info",
    Footer: "Info",
    columns: [
      {
        Header: "Date Of Birth",
        Footer: "Date Of Birth",
        accessor: "date_of_birth"
      },
      {
        Header: "Country",
        Footer: "Country",
        accessor: "country"
      },
      {
        Header: "Phone",
        Footer: "Phone",
        accessor: "phone"
      }
    ]
  }
]
```

```react
// BasicTabel.js
import { COLUMNS_GROUP } from "./columns"

const BasicTable = () => {
  const columns = useMemo(() => COLUMNS_GROUP, [])
}
```

### 5. 实现表格排序

<img src="./images/06.png"/>

```react
// SortingTable.js
import { useTable, useSortBy } from "react-table"

const SortingTable = () => {
  useTable({}, useSortBy)
  // column.getSortByToggleProps()
  // 将标记的鼠标移入样式改为手势, 表示该列是可以点击的
  // 实现点击列后, 对列数据进行排序 (升序, 降序, 默认排序交替)
  return (
    <thead>
      <th {...column.getHeaderProps(column.getSortByToggleProps())}>
        {column.render("Header")}
        <span>
          {column.isSorted ? (column.isSortedDesc ? "↓" : "↑") : ""}
        </span>
      </th>
    </thead>
  )
}
```

### 6. 单元格内容格式化

<img src="./images/07.png"/>

日期格式化：`yarn add dateformat`

```javascript
import dateformat from "dateformat"

export const COLUMNS = [
  {
    Header: "Date Of Birth",
    Footer: "Date Of Birth",
    accessor: "date_of_birth",
    Cell: ({ value }) => dateformat(value, "yyyy-mm-dd")
  }
]
```

### 7. 实现全局过滤

<img src="./images/08.png" />

```react
// GlobalFilter.js
// 进行全局搜索的搜索框组件
const GlobalFilter = ({ filter, setFilter }) => {
  return (
    <div>
      搜索:{" "}
      <input
        value={filter}
        onChange={event => setFilter(event.target.value)}
      />
    </div>
  )
}

export default GlobalFilter
```

```react
import { useGlobalFilter } from "react-table"
import GlobalFilter from "./GlobalFilter"

const FilterTable = () => {
  const { state, setGlobalFilter } = useTable({}, useGlobalFilter)
  const { globalFilter } = state
  return (
    <>
      <GlobalFilter filter={globalFilter} setFilter={setGlobalFilter} />
      <table></table>
    </>
  )
}
export default FilterTable
```

### 8. 实现列过滤

<img src="./images/09.png"/>

```react
// ColumnFilter.js
// 进行列搜索的搜索框组件
const ColumnFilter = ({ column }) => {
  const { filterValue, setFilter } = column
  return (
    <div>
      搜索:{" "}
      <input
        value={filterValue}
        onChange={event => setFilter(event.target.value)}
      />
    </div>
  )
}
export default ColumnFilter
```

```react
// FilterTable.js
import { useFilters } from "react-table"

const FilterTable = () => {
  const { } = useTable({}, useFilters, useGlobalFilter)
  return (
    <thead>
      <th>
        <div>
          {column.canFilter ? column.render("Filter") : null}
        </div>
      </th>
    </thead>
  )
}
export default FilterTable
```

```javascript
// columns.js
import ColumnFilter from "./ColumnFilter"

export const COLUMNS = [
  {
    Header: "ID",
    Footer: "ID",
    accessor: "id",
    Filter: ColumnFilter
  }
]
```

### 9. 禁用过滤

<img src="./images/10.png"/>

在表格中的某一列不想使用过滤，需要显式进行声明，否则报错，声明如下：

```javascript
// columns.js
export const COLUMNS = [
  {
    Header: "ID",
    Footer: "ID",
    accessor: "id",
    disableFilters: true
  }
]
```

### 10. 设置默认列属性

在每一列中 Filter 配置选项的值都是一样的，通过配置默认列可以去除重复配置。

```react
// FilterTable.js
import ColumnFilter from "./ColumnFilter"

const FilterTable = () => {
  const defaultColumn = useMemo(() => ({ Filter: ColumnFilter }), [])
  const {} = useTable({ defaultColumn })
}
export default FilterTable
```

然后删除 columns.js 文件中的 Filter 配置选项。

### 11. 实现过滤防抖

<img src="./images/12.gif"/>

```react
// GlobalFilter.js
import { useAsyncDebounce } from "react-table"
import { useState } from "react"

const GlobalFilter = ({ filter, setFilter }) => {
  const [value, setValue] = useState(filter)
  const onChange = useAsyncDebounce(() => {
    setFilter(value)
  }, 1000)
  return (
    <div>
      搜索:{" "}
      <input
        value={value || ""}
        onChange={event => {
          setValue(event.target.value)
          onChange()
        }}
      />
    </div>
  )
}
export default GlobalFilter
```

### 12. 实现基本分页

<img src="./images/11.png"/>

```react
// PaginationTable.js
import { usePagination } from "react-table"

const PaginationTable = () => {
  const {
    // 分页数据
    page,
    // 跳转到下一页
    nextPage,
    // 跳转到上一页
    previousPage,
    // 是否存在下一页
    canNextPage,
    // 是否存在上一页
    canPreviousPage,
    // 一共有多少页
    pageCount,
    state,
  } = useTable({}, usePagination)
  // 页码
  const { pageIndex } = state

  return (
    <>
      <table>
        <tbody>
          {page.map(row => {})}
        </tbody>
      </table>
      <div>
        <span>
          {pageIndex + 1} / {pageCount}
        </span>
        <button disabled={!canPreviousPage} onClick={() => previousPage()}>
          上一页
        </button>
        <button disabled={!canNextPage} onClick={() => nextPage()}>
          下一页
        </button>
      </div>
    </>
  )
}
export default PaginationTable
```

### 13. 实现页码跳转

<img src="./images/13.png" />

```react
import { usePagination } from "react-table"

const PaginationTable = () => {
  const { gotoPage } = useTable({ initialState: { pageIndex: 3 } }, usePagination)
  return (
    <div>
      <span>
        跳转到:{" "}
        <input
          type="number"
          style={{ width: 50 }}
          value={pageIndex + 1}
          onChange={event => gotoPage(Number(event.target.value) - 1)}
         />
      </span>
      <button disabled={!canPreviousPage} onClick={() => gotoPage(0)}>
        第一页
      </button>
      <button disabled={!canNextPage} onClick={() => gotoPage(pageCount - 1)}>
        最后一页
      </button>
    </div>
  )
}

export default PaginationTable
```

### 14. 设置数据显示条数

<img src="./images/14.png"/>

```react
import { usePagination } from "react-table"

const PaginationTable = () => {
  const { setPageSize } = useTable({initialState: {pageSize: 25}})
  const { pageSize } = state

  return (
    <select value={pageSize} onChange={event => setPageSize(Number(event.target.value))}>
      {[10, 25, 50].map(pagesize => (
        <option key={pagesize} value={pagesize}>
          显示 {pagesize} 条数据
        </option>
      ))}
    </select>
  )
}

export default PaginationTable
```

### 15. 实现选择行数据

<img src="./images/15.png"/>

```react
// Checkbox.js
import { forwardRef } from "react"
// 将 indeterminate 从 props 单独解构出来, 它不能直接被添加到 input 身上
// ref: 因为 react-table 要为复选添加功能, 要对其进行操作, 所以通过 Ref 的方式获取该复选
// rest: 通过 props 的方式向复选框中添加属性以实现复选框的单选和全选功能
const Checkbox = forwardRef(({ indeterminate, ...rest }, ref) => {
  return <input type="checkbox" ref={ref} {...rest} />
})

export default Checkbox
```

```react
// RowSelection.js
// 实现选择行数据功能
import { useRowSelect } from "react-table"
// 通过此复选框选择行数据
import Checkbox from "./Checkbox"

const RowSelection = () => {
  const {
    // 选择的结果数组
    selectedFlatRows
  } = useTable({ columns, data }, useRowSelect, hooks => {
    // 在初始化表格实例对象时调用
    // hooks: 对象, 钩子函数集合
    // 以编程方式向表格中添加列
    hooks.visibleColumns.push(columns => {
      // columns 现有的列数据
      return [
        {
          id: "selection",
          Header: ({ getToggleAllRowsSelectedProps }) => (
            // 实现全选功能
            <Checkbox {...getToggleAllRowsSelectedProps()} />
          ),
          // 实现单选功能
          Cell: ({ row }) => <Checkbox {...row.getToggleRowSelectedProps()} />
        },
        ...columns
      ]
    })
  })

  // 只显示前 10 条数据
  const firstPageRows = rows.slice(0, 10)

  return (
    <div>
      {JSON.stringify(
        { selectedRows: selectedFlatRows.map(row => row.original) },
        null,
        2
      )}
    </div>
  )
}

export default RowSelection
```

### 16. 更改列顺序

<img src="./images/16.gif"/>

在更改列顺序时，需要使用到列 id，对列 id 排序就是对列进行排序 。在没有为列添加 id 属性时， accessor 默认为列的 id。

```react
// ColumnOrder.js
import { useColumnOrder } from "react-table"

const ColumnOrder = () => {
  const { setColumnOrder } = useTable({}, useColumnOrder)
  return (
    <button
      onClick={() =>
        setColumnOrder([
          "id",
          "first_name",
          "last_name",
          "phone",
          "country",
          "date_of_birth"
        ])
       }
      >
      更改列书序
    </button>
  )
}

export default ColumnOrder
```

### 17. 显示隐藏列

<img src="./images/17.png"/>

```react
// ColumnHiding.js
import Checkbox from "./Checkbox"

const ColumnHiding = () => {
  const {
    // 列信息数组
    allColumns,
    // 显示和隐藏所有列
    getToggleHideAllColumnsProps
  } = useTable()
  return (
    <div>
      <div>
        <Checkbox {...getToggleHideAllColumnsProps()} /> 显示/隐藏所有列
      </div>
      {allColumns.map(column => (
        <div key={column.id}>
          <Checkbox {...column.getToggleHiddenProps()} /> {column.Header }
        </div>
      ))}
    </div>
  )
}
export default ColumnHiding
```

### 18. 实现列固定

<img src="./images/02.gif" />

1. 下载软件包：`yarn add react-table-sticky styled-components`   [react-table-sticky](https://github.com/GuillaumeJasmin/react-table-sticky)

2. 创建样式化组件，为表格设置样式 [simple-example](https://github.com/GuillaumeJasmin/react-table-sticky#simple-example)

   ```react
   // TableStyles.js
   import styled from "styled-components"
   
   export const Styles = styled.div`
     .table {
       border: 1px solid #ddd;
   
       .tr {
         :last-child {
           .td {
             border-bottom: 0;
           }
         }
       }
   
       .th,
       .td {
         padding: 5px;
         border-bottom: 1px solid #ddd;
         border-right: 1px solid #ddd;
         background-color: #fff;
         overflow: hidden;
   
         :last-child {
           border-right: 0;
         }
       }
   
       &.sticky {
         overflow: scroll;
         .header,
         .footer {
           position: sticky;
           z-index: 1;
           width: fit-content;
         }
   
         .header {
           top: 0;
           box-shadow: 0px 3px 3px #ccc;
         }
   
         .footer {
           bottom: 0;
           box-shadow: 0px -3px 3px #ccc;
         }
   
         .body {
           position: relative;
           z-index: 0;
         }
   
         [data-sticky-td] {
           position: sticky;
         }
   
         [data-sticky-last-left-td] {
           box-shadow: 2px 0px 3px #ccc;
         }
   
         [data-sticky-first-right-td] {
           box-shadow: -2px 0px 3px #ccc;
         }
       }
     }
   `
   ```

3. 创建 StickyTable 组件

   先拷贝 BasicTable 组件，在此基础上进行修改。

   在  [react-table-sticky](https://github.com/GuillaumeJasmin/react-table-sticky) 此处拷贝 JSX 。

   ```react
   // StickyTable.js
   // useBlockLayout
   // 为 row, cell 添加固定宽度
   // 将 row 的 display 设置为 flex
   // 将 cell 的 display 设置为 inline-block
   // 将 cell 的 box-sizing 设置 border-box
   import { useBlockLayout } from "react-table"
   import { useSticky } from "react-table-sticky"
   import { Styles } from "./TableStyles"
   
   const StickyTable = () => {
     const {} = useTable({}, useBlockLayout, useSticky)
     return (
       <Styles>
         <div
           {...getTableProps()}
           className="table sticky"
           style={{ width: 1000, height: 500 }}
         >
           <div className="header">
             {headerGroups.map(headerGroup => (
               <div {...headerGroup.getHeaderGroupProps()} className="tr">
                 {headerGroup.headers.map(column => (
                   <div {...column.getHeaderProps()} className="th">
                     {column.render("Header")}
                   </div>
                 ))}
               </div>
             ))}
           </div>
           <div {...getTableBodyProps()} className="body">
             {rows.map(row => {
               prepareRow(row)
               return (
                 <div {...row.getRowProps()} className="tr">
                   {row.cells.map(cell => (
                     <div {...cell.getCellProps()} className="td">
                       {cell.render("Cell")}
                     </div>
                   ))}
                 </div>
               )
             })}
           </div>
         </div>
       </Styles>
     )
   }
   
   export default StickyTable
   ```

4. 指定固定列，添加 Email，Age 列。

   ```javascript
   // columns.js
   export const COLUMNS = [
     {
       Header: "ID",
       Footer: "ID",
       accessor: "id",
       disableFilters: true,
       sticky: "left"
     },
     {
       Header: "First Name",
       Footer: "First Name",
       accessor: "first_name",
       sticky: "left"
     },
     {
       Header: "Last Name",
       Footer: "Last Name",
       accessor: "last_name",
       sticky: "left"
     },
     {
       Header: "Date Of Birth",
       Footer: "Date Of Birth",
       accessor: "date_of_birth",
       Cell: ({ value }) => dateformat(value, "yyyy-MM-dd")
     },
     {
       Header: "Country",
       Footer: "Country",
       accessor: "country"
     },
     {
       Header: "Phone",
       Footer: "Phone",
       accessor: "phone"
     },
     {
       Header: "Email",
       Footer: "Email",
       accessor: "email"
     },
     {
       Header: "Age",
       Footer: "Age",
       accessor: "age"
     }
   ]
   ```

### 19. 附录

1. 在父组件中获取子组件中的 DOM 元素

   ```react
   import Child from "./Child"
   import { useRef, useEffect } from "react"
   
   const Parent = () => {
     const ref = useRef()
     useEffect(() => {
       console.log(ref.current)
     }, [])
     return (
       <div>
         我是父组件
         <hr />
         <Child ref={ref} />
       </div>
     )
   }
   
   export default Parent
   ```

   ```react
   import { forwardRef } from "react"
   
   const Child = forwardRef((props, ref) => {
     return (
       <div ref={ref} {...props}>
         我是子组件
       </div>
     )
   })
   
   export default Child
   ```


