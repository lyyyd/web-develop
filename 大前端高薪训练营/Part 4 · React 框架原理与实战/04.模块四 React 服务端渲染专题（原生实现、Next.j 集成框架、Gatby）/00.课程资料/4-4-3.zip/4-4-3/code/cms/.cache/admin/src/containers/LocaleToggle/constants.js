/*
 *
 * LocaleToggle constants
 *
 */

export const RESET_DEFAULT_CLASSNAME = 'StrapiAdmin/LocaleToggle/RESET_DEFAULT_CLASSNAME';
export const SET_CUSTOM_CLASSNAME = 'StrapiAdmin/LocaleToggle/SET_CUSTOM_CLASSNAME';
