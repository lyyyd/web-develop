/* eslint-disable jsx-a11y/click-events-have-key-events */
import { upperFirst } from 'lodash';

const UpperFirst = ({ content }) => upperFirst(content);

export default UpperFirst;
