import styled from 'styled-components';

const Wrapper = styled.div`
  padding: 12px 10px;
`;

export default Wrapper;
