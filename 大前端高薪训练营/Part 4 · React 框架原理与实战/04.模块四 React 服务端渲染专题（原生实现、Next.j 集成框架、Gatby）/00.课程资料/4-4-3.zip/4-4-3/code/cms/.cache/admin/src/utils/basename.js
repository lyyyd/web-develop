const basename = PUBLIC_PATH.replace(window.location.origin, '');

export default basename;
