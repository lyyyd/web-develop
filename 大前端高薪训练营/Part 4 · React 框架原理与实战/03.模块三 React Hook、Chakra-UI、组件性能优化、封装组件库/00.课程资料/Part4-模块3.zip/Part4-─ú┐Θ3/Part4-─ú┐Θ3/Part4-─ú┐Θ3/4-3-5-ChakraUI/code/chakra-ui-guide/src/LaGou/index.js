import LaGouButton from './button';

export default {
  LaGouButton
}