

function fn() {
  name = 'lg'
  console.log(`${name} is a coder`)
}

fn() 


function fn() {
  const name = 'lg'
  console.log(`${name} is a coder`)
}

fn() 

