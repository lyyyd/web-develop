
// let test = () => {
//   let obj = new Object()
//   obj.name = 'zce'
//   obj.age = 38
//   obj.slogan = '我为前端而活'
//   return obj
// }

// let test = () => {
//   let obj = {
//     name: 'zce',
//     age: 38,
//     slogan : '我为前端而活'
//   }
//   return obj
// }
// console.log(test())

var str1 = 'zce说我为前端而活'
var str2 = new String('zce说我为前端而活')


console.log(str1)
console.log(str2)